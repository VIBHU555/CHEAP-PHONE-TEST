// Builds PocketTest_AI_HackFront_Presentation.pptx
// Every measured number comes from docs/demo-scenario-results.json (real runs) and docs/TESTING_REPORT.json (real test run).
//   NODE_PATH=$(npm root -g) node presentation/build_deck.js
const fs = require('fs');
const path = require('path');
const pptxgen = require('pptxgenjs');
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');
const sharp = require('sharp');
const fa = require('react-icons/fa');
const { applyTheme } = require('/mnt/skills/public/pptx/scripts/apply_theme.js');

const ROOT = path.resolve(__dirname, '..');
const R = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs/demo-scenario-results.json'), 'utf8'));
const T = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs/TESTING_REPORT.json'), 'utf8'));
const SHOT = (n) => path.join(ROOT, 'docs/screenshots', n);
const OUT = path.join(__dirname, 'PocketTest_AI_HackFront_Presentation.pptx');

// ---- measured values (never typed by hand)
const S = R.summaries;
const homeLoad = (k) => Math.round(S[k].by_page['/'].load_ms);
const prodMs = (k) => Math.round(S[k].by_endpoint['GET /api/products'].median_ms);
const homeKB = (k) => Math.round(S[k].by_page['/'].transfer_bytes / 1024);
const issues = (k) => Object.values(S[k].issue_counts).reduce((a, b) => a + b, 0);
const fixCmp = R.compare_fix_constrained_before_vs_after;
const fixPct = fixCmp.pages['/'].load_ms.pct;               // e.g. -83.4
const sec = (ms) => (ms / 1000).toFixed(1) + ' s';

const THEME = {
  name: 'PocketTest', headFontFace: 'Calibri', bodyFontFace: 'Calibri',
  colors: { dk1: '0B1220', lt1: 'FFFFFF', dk2: '11203B', lt2: 'EEF3FA', accent1: '0EA5E9', accent2: 'F59E0B', accent3: '10B981', accent4: '8B5CF6', accent5: 'EF4444', accent6: '64748B', hlink: '0EA5E9', folHlink: '64748B' },
};
const HEX = { navy: '0B1220', navy2: '11203B', cyan: '38BDF8', blue: '0EA5E9', amber: 'F59E0B', green: '10B981', violet: '8B5CF6', red: 'EF4444', slate: '64748B', light: 'EEF3FA', white: 'FFFFFF', line: 'D5DEEB', mute: '475569' };

async function icon(Comp, color, size = 256) {
  const svg = renderToStaticMarkup(React.createElement(Comp, { color: '#' + color, size: String(size) }));
  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  return 'image/png;base64,' + buf.toString('base64');
}

(async () => {
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_WIDE';                                   // 13.33 x 7.5 in
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  pres.title = 'PocketTest AI — HackFront India: The Cheap Phone Test';
  pres.author = '[TEAM NAME]';
  const C = pres.SchemeColor;
  const shadow = () => ({ type: 'outer', color: '000000', opacity: 0.12, blur: 8, offset: 2, angle: 90 });

  // ---------------- layouts
  pres.defineSlideMaster({ title: 'DARK_TITLE', background: { color: HEX.navy }, objects: [], slideNumber: undefined });
  pres.defineSlideMaster({
    title: 'CONTENT', background: { color: HEX.light },
    objects: [{ text: { text: 'PocketTest AI  ·  HackFront India  ·  The Cheap Phone Test', options: { x: 0.6, y: 7.05, w: 8, h: 0.3, fontSize: 10, color: HEX.slate, margin: 0, isTextBox: true } } }],
    slideNumber: { x: 12.2, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: HEX.slate, align: 'right' },
    margin: [0.4, 0.6, 0.55, 0.6],
  });
  const withTitle = (slide, text) => slide.addText(text, { x: 0.6, y: 0.4, w: 12.1, h: 0.85, fontSize: 34, bold: true, color: C.text2, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Title' });

  const card = (s, x, y, w, h, name) => s.addShape(pres.ShapeType.roundRect, { x, y, w, h, rectRadius: 0.12, fill: { color: C.background1 }, line: { color: HEX.line, width: 0.75 }, shadow: shadow(), objectName: name });
  const dot = async (s, Comp, x, y, d, bg, fg = HEX.white, name = 'Icon') => {
    s.addShape(pres.ShapeType.ellipse, { x, y, w: d, h: d, fill: { color: bg }, line: { color: bg, width: 0 }, objectName: name + ' bg' });
    s.addImage({ data: await icon(Comp, fg), x: x + d * 0.24, y: y + d * 0.24, w: d * 0.52, h: d * 0.52, altText: name });
  };
  const chip = (s, text, x, y, w, bg, fg = HEX.white) => s.addText(text, { x, y, w, h: 0.32, fontSize: 12, bold: true, color: fg, fill: { color: bg }, align: 'center', valign: 'middle', margin: 0, isTextBox: true, shape: pres.ShapeType.roundRect, rectRadius: 0.16, objectName: 'Chip ' + text });

  // ======================================================== 1. Title
  pres.addSection({ title: 'Intro' });
  let s = pres.addSlide({ masterName: 'DARK_TITLE', sectionTitle: 'Intro' });
  s.addImage({ data: await icon(fa.FaCheckCircle, HEX.cyan), x: 0.8, y: 1.2, w: 0.9, h: 0.9, altText: 'PocketTest AI logo mark' });
  s.addText('PocketTest AI', { x: 0.8, y: 2.25, w: 11.5, h: 1.2, fontSize: 66, bold: true, color: HEX.white, margin: 0, isTextBox: true, objectName: 'Title' });
  s.addText('Test for Everyone. Build for Every Device.', { x: 0.8, y: 3.45, w: 11.5, h: 0.6, fontSize: 28, color: HEX.cyan, italic: true, margin: 0, isTextBox: true });
  s.addText('Browser-based performance and failure testing under constrained conditions — with measured evidence, not guesses.', { x: 0.8, y: 4.3, w: 9.6, h: 0.9, fontSize: 18, color: 'C9D6E8', margin: 0, isTextBox: true });
  s.addText('HackFront India  ·  The Cheap Phone Test', { x: 0.8, y: 6.0, w: 7, h: 0.35, fontSize: 14, bold: true, color: HEX.white, margin: 0, isTextBox: true });
  s.addText('[TEAM NAME]  ·  [MEMBER NAMES]  ·  [CONTACT]   (placeholders — fill in before submission)', { x: 0.8, y: 6.4, w: 11, h: 0.35, fontSize: 12, color: '9FB0C8', margin: 0, isTextBox: true });
  s.addNotes('Open with the tagline. One sentence: PocketTest AI helps developers see how their web app behaves when bandwidth, latency and CPU are constrained — and gives them evidence they can act on. Team names are placeholders; replace them before presenting. Be upfront that everything shown is measured in desktop Chromium with emulated conditions, not on physical phones.');

  // ======================================================== 2. Problem
  pres.addSection({ title: 'Problem and solution' });
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Problem and solution' });
  withTitle(s, 'Apps get tested where conditions are easy');
  const probs = [[fa.FaHourglassHalf, 'Slow startup and page loads', 'Heavy bundles and images dominate on limited bandwidth.'], [fa.FaPlug, 'Failed or slow network requests', 'APIs that look fine on fast links can exceed latency budgets.'],
    [fa.FaBug, 'Errors that only some users hit', 'Uncaught exceptions and degraded pages go unnoticed.'], [fa.FaChartLine, 'Regressions shipped unseen', 'Without a reproducible baseline, slowdowns slip through.']];
  for (let i = 0; i < probs.length; i++) {
    const y = 1.55 + i * 1.3;
    card(s, 0.6, y, 7.3, 1.12, 'Problem card ' + (i + 1));
    await dot(s, probs[i][0], 0.85, y + 0.2, 0.72, HEX.blue, HEX.white, probs[i][1]);
    s.addText(probs[i][1], { x: 1.8, y: y + 0.14, w: 5.9, h: 0.4, fontSize: 20, bold: true, color: C.text2, margin: 0, isTextBox: true });
    s.addText(probs[i][2], { x: 1.8, y: y + 0.54, w: 5.9, h: 0.45, fontSize: 14, color: HEX.mute, margin: 0, isTextBox: true });
  }
  card(s, 8.3, 1.55, 4.4, 5.0, 'Measured callout');
  s.addText('MEASURED IN OUR DEMO APP', { x: 8.55, y: 1.75, w: 3.9, h: 0.3, fontSize: 12, bold: true, color: HEX.slate, margin: 0, isTextBox: true });
  s.addText(sec(homeLoad('constrained_before')), { x: 8.55, y: 2.1, w: 3.9, h: 1.2, fontSize: 66, bold: true, color: HEX.red, margin: 0, isTextBox: true, objectName: 'Stat' });
  s.addText(`home-page load under the example Constrained profile (1000 kbps, 150 ms latency, 4x CPU) — versus ${homeLoad('standard_before')} ms unconstrained.`, { x: 8.55, y: 3.35, w: 3.9, h: 1.3, fontSize: 15, color: C.text1, margin: 0, isTextBox: true });
  s.addText(`The page transfers ${homeKB('constrained_before')} KB. Nothing “fails” on a fast laptop, so nobody notices.`, { x: 8.55, y: 4.7, w: 3.9, h: 1.0, fontSize: 14, color: HEX.mute, margin: 0, isTextBox: true });
  s.addText('Example configuration, not a model of any specific phone or network.', { x: 8.55, y: 5.85, w: 3.9, h: 0.5, fontSize: 11, italic: true, color: HEX.slate, margin: 0, isTextBox: true });
  s.addNotes('The problem is not that developers are careless — it is that the fast path is the only path they can easily see. In our controlled demo app, the home page loads in a few tens of milliseconds on an unconstrained browser but takes several seconds once we apply an example constrained profile. These are measured values from our own runs, not industry statistics. The profile is a test configuration; we do not claim it represents any particular Indian smartphone or carrier.');

  // ======================================================== 3. Users
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Problem and solution' });
  withTitle(s, 'Built for the people who ship the app');
  const users = [[fa.FaCode, 'Developers', 'Reproduce a slow or failing path in minutes and get evidence to start debugging.', 'Without a device lab or a throttling proxy to set up.'],
    [fa.FaClipboardCheck, 'QA engineers', 'Re-run the same workflow under named profiles and compare before/after.', 'Consistent conditions instead of “it felt slow”.'],
    [fa.FaUsers, 'Small teams and students', 'Run locally on a laptop with no paid infrastructure.', 'Hackathon-friendly: install, run, test.']];
  for (let i = 0; i < 3; i++) {
    const x = 0.6 + i * 4.1;
    card(s, x, 1.6, 3.9, 3.3, 'User card ' + (i + 1));
    await dot(s, users[i][0], x + 0.3, 1.85, 0.8, HEX.navy2, HEX.cyan, users[i][1]);
    s.addText(users[i][1], { x: x + 0.3, y: 2.8, w: 3.3, h: 0.45, fontSize: 22, bold: true, color: C.text2, margin: 0, isTextBox: true });
    s.addText(users[i][2], { x: x + 0.3, y: 3.3, w: 3.3, h: 0.9, fontSize: 14, color: C.text1, margin: 0, valign: 'top', isTextBox: true });
    s.addText(users[i][3], { x: x + 0.3, y: 4.2, w: 3.3, h: 0.6, fontSize: 13, italic: true, color: HEX.mute, margin: 0, isTextBox: true });
  }
  s.addText('Consequences when this is missed', { x: 0.6, y: 5.2, w: 12, h: 0.4, fontSize: 18, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText([{ text: 'Users on weaker devices or connections may abandon slow pages and failed checkouts.', options: { bullet: true, breakLine: true } }, { text: 'Regressions reach production because there was no reproducible baseline.', options: { bullet: true, breakLine: true } }, { text: 'Teams argue from anecdotes instead of measurements.', options: { bullet: true } }],
    { x: 0.6, y: 5.6, w: 12, h: 1.25, fontSize: 15, color: C.text1, margin: 0, paraSpaceAfter: 4, valign: 'top', isTextBox: true });
  s.addNotes('Three audiences. We deliberately avoid quoting user numbers or market statistics — we do not have verified ones for this prototype. The consequences listed are plausible and well understood in the field, but they are stated as risks, not as findings from our work.');

  // ======================================================== 4. Solution
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Problem and solution' });
  withTitle(s, 'One workflow from configuration to evidence');
  const flow = [['Configure', 'target, profile, workflow'], ['Execute', 'real Chromium via Playwright'], ['Measure', 'timings, requests, errors'], ['Classify', 'transparent severity rules'], ['Explain', 'evidence-based report'], ['Compare', 'before vs after']];
  flow.forEach((f, i) => {
    const x = 0.6 + i * 2.05;
    s.addShape(pres.ShapeType.chevron, { x, y: 1.6, w: 2.0, h: 1.0, fill: { color: i % 2 ? HEX.navy2 : HEX.blue }, line: { color: HEX.white, width: 1 }, objectName: 'Flow ' + f[0] });
    s.addText(f[0], { x: x + 0.35, y: 1.6, w: 1.4, h: 1.0, fontSize: 16, bold: true, color: HEX.white, align: 'center', valign: 'middle', margin: 0, isTextBox: true });
    s.addText(f[1], { x, y: 2.7, w: 2.0, h: 0.6, fontSize: 12, color: HEX.mute, align: 'center', margin: 0, isTextBox: true });
  });
  s.addText('Every result is labelled with where it came from', { x: 0.6, y: 3.65, w: 12, h: 0.4, fontSize: 20, bold: true, color: C.text2, margin: 0, isTextBox: true });
  const kinds = [['MEASURED', HEX.green, 'Recorded by the browser or test engine during the run.'], ['SIMULATED', HEX.amber, 'Produced by a deliberate simulation (e.g. injected request aborts for packet loss).'], ['ESTIMATED', HEX.blue, 'Simple arithmetic on measured values, e.g. payload ÷ configured bandwidth.'], ['HYPOTHESIS', HEX.violet, 'A possible explanation consistent with evidence — not confirmed.']];
  kinds.forEach((k, i) => {
    const x = 0.6 + i * 3.08;
    card(s, x, 4.15, 2.9, 2.2, 'Provenance ' + k[0]);
    chip(s, k[0], x + 0.25, 4.4, 1.5, k[1], k[1] === HEX.amber ? HEX.navy : HEX.white);
    s.addText(k[2], { x: x + 0.25, y: 4.9, w: 2.45, h: 1.3, fontSize: 14, color: C.text1, margin: 0, valign: 'top', isTextBox: true });
  });
  s.addNotes('This is the product in one line: configure, execute, measure, classify, explain, compare. The distinctive idea is provenance: every number or sentence in a report is tagged measured, simulated, estimated or hypothesis, so a developer always knows what is evidence and what is a lead. Severity comes from documented, configurable rules — never from an LLM.');

  // ======================================================== 5. How it operates (real scenario)
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Problem and solution' });
  withTitle(s, 'The demonstrated workflow, with real numbers');
  const steps = [['1  Standard run', `${homeLoad('standard_before')} ms`, `home load · ${issues('standard_before')} issues`, 'Deliberate faults found: timeout, HTTP 500, JS error', HEX.slate],
    ['2  Constrained run', `${homeLoad('constrained_before')} ms`, `home load · ${issues('constrained_before')} issues`, 'Slow API and slow page now appear', HEX.red],
    ['3  Diagnostic report', 'evidence', 'observation ≠ hypothesis', 'Server 451 ms of 1489 ms → rest is outside server', HEX.violet],
    ['4  Apply sample fix', 'optimized', 'demo-app switch', 'Smaller bundle/image/payload, faults removed', HEX.blue],
    ['5  Re-run + compare', `${homeLoad('constrained_after')} ms`, `${fixPct.toFixed(1)}% · ${issues('constrained_after')} issues`, `${fixCmp.resolved_failures.length} resolved, ${fixCmp.new_failures.length} new failures`, HEX.green]];
  steps.forEach((st, i) => {
    const x = 0.6 + i * 2.45;
    card(s, x, 1.65, 2.3, 3.95, 'Step ' + (i + 1));
    s.addText(st[0], { x: x + 0.2, y: 1.8, w: 1.95, h: 0.5, fontSize: 15, bold: true, color: C.text2, margin: 0, isTextBox: true });
    s.addText(st[1], { x: x + 0.2, y: 2.45, w: 1.95, h: 0.8, fontSize: st[1].length > 7 ? 24 : 34, bold: true, color: st[4], margin: 0, isTextBox: true, valign: 'middle' });
    s.addText(st[2], { x: x + 0.2, y: 3.3, w: 1.95, h: 0.55, fontSize: 13, bold: true, color: HEX.mute, margin: 0, isTextBox: true });
    s.addText(st[3], { x: x + 0.2, y: 4.0, w: 1.95, h: 1.5, fontSize: 14, color: C.text1, margin: 0, valign: 'top', isTextBox: true });
  });
  s.addText('Steps 1, 2 and 5 use the Standard / Constrained / Constrained profiles on the same workflow; 3 repetitions each. Source: docs/demo-scenario-results.json.', { x: 0.6, y: 5.85, w: 12.1, h: 0.5, fontSize: 12, italic: true, color: HEX.slate, margin: 0, isTextBox: true });
  s.addNotes(`These numbers are from real runs executed by scripts/run_demo_scenario.py (3 repetitions each). Standard network: ${homeLoad('standard_before')} ms home-page load. Constrained: ${homeLoad('constrained_before')} ms. After applying the demo app's sample optimization and re-running under the identical constrained profile: ${homeLoad('constrained_after')} ms (${fixPct.toFixed(1)}%), with ${fixCmp.resolved_failures.length} findings resolved and ${fixCmp.new_failures.length} new. Note this improvement is for our deliberately inefficient demo app; it is not a claim about any real-world app.`);

  // ======================================================== 6. Architecture
  pres.addSection({ title: 'Build' });
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Build' });
  withTitle(s, 'Architecture and technology stack');
  const box = (x, y, w, h, title, sub, fill, fg = HEX.white) => {
    s.addShape(pres.ShapeType.roundRect, { x, y, w, h, rectRadius: 0.1, fill: { color: fill }, line: { color: fill, width: 0 }, shadow: shadow(), objectName: 'Box ' + title });
    s.addText([{ text: title, options: { bold: true, fontSize: 15, breakLine: true } }, { text: sub, options: { fontSize: 11 } }], { x: x + 0.1, y, w: w - 0.2, h, color: fg, align: 'center', valign: 'middle', margin: 0, isTextBox: true });
  };
  const arrow = (x1, y1, x2, y2) => s.addShape(pres.ShapeType.line, { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1) || 0.001, h: Math.abs(y2 - y1) || 0.001, line: { color: HEX.slate, width: 1.5, endArrowType: 'triangle' } });
  box(0.6, 1.6, 2.4, 1.0, 'Browser UI', '8 pages · ES modules · SVG charts', HEX.navy2);
  box(3.6, 1.6, 2.6, 1.0, 'Flask REST API', 'validation · limits · static files', HEX.blue);
  box(6.8, 1.6, 2.6, 1.0, 'RunManager', '1 worker thread/run · cancel', HEX.navy2);
  box(3.6, 3.2, 2.6, 1.0, 'SQLite repository', 'schema.sql · Postgres-ready seam', HEX.slate);
  box(6.8, 3.2, 2.6, 1.0, 'Engine', 'Playwright + Chromium · CDP', HEX.green);
  box(10.0, 3.2, 2.7, 1.0, 'Demo app “PocketShop”', 'deliberate, reproducible faults', HEX.amber, HEX.navy);
  box(6.8, 4.8, 2.6, 1.0, 'Classifier + Analysis', 'rules → findings → report', HEX.violet);
  box(3.6, 4.8, 2.6, 1.0, 'Compare / Export', 'JSON · CSV · diffs', HEX.slate);
  arrow(3.0, 2.1, 3.6, 2.1); arrow(6.2, 2.1, 6.8, 2.1); arrow(8.1, 2.6, 8.1, 3.2); arrow(8.1, 4.2, 8.1, 4.8); arrow(4.9, 2.6, 4.9, 3.2); arrow(6.8, 5.3, 6.2, 5.3); arrow(9.4, 3.7, 10.0, 3.7);
  s.addText('Stack', { x: 0.6, y: 3.3, w: 2.4, h: 0.4, fontSize: 18, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText([{ text: 'Python 3.12 · Flask', options: { bullet: true, breakLine: true } }, { text: 'Playwright · Chromium', options: { bullet: true, breakLine: true } }, { text: 'SQLite', options: { bullet: true, breakLine: true } }, { text: 'Vanilla ES modules, SVG', options: { bullet: true, breakLine: true } }, { text: 'unittest · node:test', options: { bullet: true } }],
    { x: 0.6, y: 3.75, w: 2.7, h: 2.1, fontSize: 14, color: C.text1, margin: 0, paraSpaceAfter: 3, valign: 'top', isTextBox: true });
  card(s, 10.0, 4.8, 2.7, 1.0, 'Deviation note');
  s.addText('Deviation from the brief: Flask / vanilla JS / unittest instead of FastAPI / React / pytest (not installable offline).', { x: 10.12, y: 4.8, w: 2.5, h: 1.0, fontSize: 11, italic: true, color: HEX.mute, margin: 0, valign: 'middle', isTextBox: true });
  s.addText('Arrows show request / data flow. The engine only reaches registered target origins. The demo app is isolated from product code.', { x: 0.6, y: 6.2, w: 11.5, h: 0.4, fontSize: 12, italic: true, color: HEX.slate, margin: 0, isTextBox: true });
  s.addNotes('Clean seams: UI → REST → RunManager → Engine, with the classifier, report generator and comparison as pure Python modules. SQL is isolated in one repository file, so PostgreSQL is a swap. We want to be transparent about the stack: the brief preferred FastAPI, React and pytest; our build environment had no network, so we used Flask, plain ES modules and unittest, which we could actually run and verify. The architecture is the same, so a port is mechanical.');

  // ======================================================== 7. Features
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Build' });
  withTitle(s, 'Technical contribution: evidence you can trust');
  const feats = [[fa.FaTachometerAlt, 'Enforced, verified conditions', 'Bandwidth, latency and CPU applied via Chromium DevTools; observed throughput is checked against the requested limit. If a constraint cannot be applied, the run fails.'],
    [fa.FaTags, 'Provenance on every claim', 'Measured, simulated, estimated or hypothesis — in evidence lines, causes and tables.'],
    [fa.FaBalanceScale, 'Deterministic severity', 'Documented, configurable rules classify issues. An LLM never assigns severity, and none is required.'],
    [fa.FaSearch, 'Server vs network split', 'Browser latency and server-reported time are separate; the report shows what falls outside server processing.'],
    [fa.FaShieldAlt, 'Safe by default', 'Registered targets only, metadata/link-local blocked, page requests confined to the target origin.'],
    [fa.FaExchangeAlt, 'Compatible comparisons', 'Same workflow required; differing conditions raise warnings; percent change only when valid.']];
  for (let i = 0; i < 6; i++) {
    const x = 0.6 + (i % 3) * 4.1, y = 1.55 + Math.floor(i / 3) * 2.7;
    card(s, x, y, 3.9, 2.5, 'Feature ' + (i + 1));
    await dot(s, feats[i][0], x + 0.25, y + 0.22, 0.6, HEX.blue, HEX.white, feats[i][1]);
    s.addText(feats[i][1], { x: x + 1.0, y: y + 0.22, w: 2.75, h: 0.6, fontSize: 16, bold: true, color: C.text2, valign: 'middle', margin: 0, isTextBox: true });
    s.addText(feats[i][2], { x: x + 0.25, y: y + 0.95, w: 3.4, h: 1.45, fontSize: 13, color: C.text1, margin: 0, valign: 'top', isTextBox: true });
  }
  s.addNotes('Six things that make this more than a dashboard. The two we are proudest of: enforcement is verified rather than assumed — if Chromium were not actually throttling, the report would say so — and every statement carries its provenance so a hypothesis can never masquerade as a measurement. Packet loss is the clearest example of honesty: we simulate it by aborting requests and label it simulated everywhere.');

  // ======================================================== 8. Screenshots
  pres.addSection({ title: 'Evidence' });
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Evidence' });
  withTitle(s, 'The working prototype (real screenshots)');
  const shots = [['04c-report-finding.png', 'Diagnostic report: evidence, estimate and hypothesis kept separate'], ['05-compare.png', 'Run comparison: constrained network, before vs after the fix']];
  for (let i = 0; i < shots.length; i++) {
    const x = 0.6 + i * 6.15, boxW = 5.95, boxH = 4.2;
    const meta = await sharp(SHOT(shots[i][0])).metadata();
    let w = boxW, h = (boxW * meta.height) / meta.width;
    if (h > boxH) { h = boxH; w = (boxH * meta.width) / meta.height; }
    s.addShape(pres.ShapeType.roundRect, { x, y: 1.5, w: boxW, h: boxH, rectRadius: 0.08, fill: { color: HEX.navy }, line: { color: HEX.line, width: 0.75 }, objectName: 'Frame ' + (i + 1) });
    s.addImage({ path: SHOT(shots[i][0]), x: x + (boxW - w) / 2, y: 1.5 + (boxH - h) / 2, w, h, altText: 'Screenshot: ' + shots[i][1] });
    s.addText(shots[i][1], { x, y: 5.8, w: boxW, h: 0.4, fontSize: 14, bold: true, color: C.text2, margin: 0, isTextBox: true });
  }
  s.addText('Also built and screenshotted (docs/screenshots): dashboard, new-test form, live execution, results with enforcement table, history, settings.', { x: 0.6, y: 6.3, w: 12.1, h: 0.5, fontSize: 12, italic: true, color: HEX.slate, margin: 0, isTextBox: true });
  s.addNotes('Real screenshots captured from the running application with scripts/capture_screenshots.py, using the runs from the demo scenario. Left: one finding in the diagnostic report — a confirmed observation, evidence tagged by provenance, and possible causes tagged estimated or hypothesis, with a confidence note. Right: comparison of the constrained run before and after the sample optimization, with differences and resolved failures. The results page with its enforcement table is in docs/screenshots.');

  // ======================================================== 9. Testing & results
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Evidence' });
  withTitle(s, 'Testing methodology and actual results');
  const stats = [[String(T.implemented), 'tests implemented', HEX.navy2], [String(T.executed), 'executed', HEX.navy2], [String(T.passed), 'passed', HEX.green], [String(T.failed), 'failed', T.failed ? HEX.red : HEX.slate], [String(T.not_executed), 'not executed', HEX.slate]];
  stats.forEach((st, i) => {
    const x = 0.6 + i * 1.5;
    card(s, x, 1.5, 1.4, 1.35, 'Stat ' + st[1]);
    s.addText(st[0], { x, y: 1.55, w: 1.4, h: 0.8, fontSize: 40, bold: true, color: st[2], align: 'center', valign: 'middle', margin: 0, isTextBox: true });
    s.addText(st[1], { x, y: 2.3, w: 1.4, h: 0.45, fontSize: 11, color: HEX.mute, align: 'center', margin: 0, isTextBox: true });
  });
  s.addText(T.layers.map((l, i) => ({ text: `${l.count}  ${l.name}`, options: { bullet: true, breakLine: i < T.layers.length - 1 } })),
    { x: 0.6, y: 3.1, w: 7.0, h: 2.35, fontSize: 14, color: C.text1, margin: 0, paraSpaceAfter: 5, valign: 'top', isTextBox: true });
  s.addText(`Run on ${T.environment}; ${T.duration_s} s. Covers startup, health, validation, invalid-target rejection, execution, timeouts, failed requests, thresholds, reports, persistence, comparison, export, security and browser cleanup.`, { x: 0.6, y: 5.55, w: 7.0, h: 1.2, fontSize: 12, italic: true, color: HEX.slate, margin: 0, isTextBox: true });
  card(s, 7.9, 1.5, 4.8, 5.25, 'Chart card');
  s.addChart(pres.charts.BAR, [{ name: 'Home-page load (ms)', labels: ['Standard\nbefore fix', 'Constrained\nbefore fix', 'Constrained\nafter fix', 'Standard\nafter fix'], values: [homeLoad('standard_before'), homeLoad('constrained_before'), homeLoad('constrained_after'), homeLoad('standard_after')] }],
    { x: 8.0, y: 1.6, w: 4.6, h: 4.2, barDir: 'col', chartColors: [HEX.slate, HEX.red, HEX.green, HEX.green], showTitle: true, title: 'Median home-page load, measured (ms)', titleFontSize: 13, titleColor: HEX.navy2, showValue: true, dataLabelPosition: 'outEnd', dataLabelFontSize: 11, dataLabelColor: HEX.navy, dataLabelFontFace: '+mn-lt',
      catAxisLabelColor: HEX.mute, catAxisLabelFontSize: 10, catAxisLabelFontFace: '+mn-lt', valAxisLabelColor: HEX.mute, valAxisLabelFontSize: 10, valAxisLabelFontFace: '+mn-lt', valGridLine: { color: HEX.line, size: 0.5 }, catGridLine: { style: 'none' }, showLegend: false, barGapWidthPct: 60 });
  s.addText(`Issues found: ${issues('standard_before')} · ${issues('constrained_before')} · ${issues('constrained_after')} · ${issues('standard_after')} (same order). 3 repetitions each.`, { x: 8.05, y: 5.85, w: 4.5, h: 0.8, fontSize: 12, color: HEX.mute, margin: 0, isTextBox: true });
  s.addNotes(`The test numbers come from a real run of the full suite (python -m unittest discover -s tests): ${T.implemented} implemented, ${T.executed} executed, ${T.passed} passed, ${T.failed} failed, ${T.not_executed} not executed. Writing the tests found two real bugs in our own code — a skip link that broke hash routing, and a hang when reading sizes of requests that never finished — both fixed. The chart is the measured median home-page load from the scenario. Small sample: 3 repetitions per run, so treat these as indicative.`);

  // ======================================================== 10. Limits & security
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Evidence' });
  withTitle(s, 'Limitations, security and reliability');
  card(s, 0.6, 1.5, 6.0, 4.7, 'Limitations card'); card(s, 6.8, 1.5, 5.9, 4.7, 'Safeguards card');
  await dot(s, fa.FaExclamationTriangle, 0.85, 1.7, 0.55, HEX.amber, HEX.navy, 'Limitations');
  s.addText('What this does not do', { x: 1.55, y: 1.7, w: 4.8, h: 0.55, fontSize: 20, bold: true, color: C.text2, valign: 'middle', margin: 0, isTextBox: true });
  const lims = ['Not a physical-device benchmark: desktop Chromium with emulation', 'Does not measure RAM, battery, thermals or real-device crashes', 'Packet loss is simulated (aborted requests), labelled as such', 'Small samples (1–10 repetitions); no confidence intervals', 'Local, single-user, no authentication', 'LLM explanations implemented but live API call not yet exercised', 'PDF export not implemented; video has captions, no voice-over'];
  s.addText(lims.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < lims.length - 1 } })), { x: 0.85, y: 2.4, w: 5.5, h: 4.2, fontSize: 14, color: C.text1, margin: 0, paraSpaceAfter: 6, valign: 'top', isTextBox: true });
  await dot(s, fa.FaLock, 7.05, 1.7, 0.55, HEX.green, HEX.white, 'Safeguards');
  s.addText('Safeguards (tested)', { x: 7.75, y: 1.7, w: 4.7, h: 0.55, fontSize: 20, bold: true, color: C.text2, valign: 'middle', margin: 0, isTextBox: true });
  const safe = ['Registered targets only; foreign, credentialed and metadata URLs rejected', 'Page requests confined to the target origin', 'No shell commands built from input; secrets only via env vars', 'Timeouts, run cap, 1 concurrent run, request-size limit', 'Browser always cleaned up — even after errors and cancellation', 'Unenforceable constraint → run fails, never silently unconstrained', 'CSV formula-injection guard; XSS-tested UI'];
  s.addText(safe.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < safe.length - 1 } })), { x: 7.05, y: 2.4, w: 5.5, h: 4.2, fontSize: 14, color: C.text1, margin: 0, paraSpaceAfter: 6, valign: 'top', isTextBox: true });
  s.addNotes('Be direct about limits — judges will respect it. The biggest: this is browser emulation on a laptop, not a physical Android device. We do not claim to measure memory, battery or crashes. The safeguards on the right are each covered by an automated test. One thing we have not done: the optional LLM explanation path has not been run against the live API, because the build environment had no network or key; the parsing, labelling and fallback are tested with a stub.');

  // ======================================================== 11. Roadmap
  pres.addSection({ title: 'Close' });
  s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: 'Close' });
  withTitle(s, 'Roadmap and potential impact');
  const cols = [['Implemented now', HEX.green, ['Playwright/Chromium engine', 'CDP bandwidth, latency, CPU + verification', 'Rules-based findings, reports', 'Run comparison, history, JSON/CSV export', `${T.implemented} automated tests`]],
    ['Planned next', HEX.blue, ['Proxy / tc-based shaping', 'Workflow recorder, custom steps', 'Web Vitals (INP, CLS, TBT), HAR export', 'CI gate: fail build on severity', 'React/FastAPI port, PostgreSQL']],
    ['Longer term', HEX.violet, ['Android emulator and device-farm runners', 'Memory / CPU traces (adb, Perfetto)', 'Statistical comparison with CIs', 'Scheduled runs, multi-user, auth']]];
  cols.forEach((c, i) => {
    const x = 0.6 + i * 4.1;
    card(s, x, 1.5, 3.9, 3.85, 'Roadmap ' + c[0]);
    chip(s, c[0].toUpperCase(), x + 0.25, 1.72, 2.3, c[1]);
    s.addText(c[2].map((t, j) => ({ text: t, options: { bullet: true, breakLine: j < c[2].length - 1 } })), { x: x + 0.25, y: 2.2, w: 3.45, h: 3.0, fontSize: 14, color: C.text1, margin: 0, paraSpaceAfter: 5, valign: 'top', isTextBox: true });
  });
  s.addText('Potential impact (qualitative — no adoption numbers claimed)', { x: 0.6, y: 5.6, w: 12, h: 0.4, fontSize: 18, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText('Make “test on a constrained connection” a five-minute, repeatable step for any team — so performance and failure issues surface before release, with evidence instead of anecdotes.', { x: 0.6, y: 6.0, w: 12.1, h: 0.8, fontSize: 15, color: C.text1, margin: 0, isTextBox: true });
  s.addNotes('Separate what exists from what is planned — the green column is implemented and tested today; the others are roadmap, not features. The impact statement is deliberately qualitative: we have no users, partners or adoption figures, and we are not inventing any.');

  // ======================================================== 12. Conclusion
  s = pres.addSlide({ masterName: 'DARK_TITLE', sectionTitle: 'Close' });
  s.addText('Test for Everyone.', { x: 0.8, y: 1.3, w: 11.5, h: 1.0, fontSize: 54, bold: true, color: HEX.white, margin: 0, isTextBox: true, objectName: 'Title' });
  s.addText('Build for Every Device.', { x: 0.8, y: 2.3, w: 11.5, h: 1.0, fontSize: 54, bold: true, color: HEX.cyan, margin: 0, isTextBox: true });
  s.addText('Reproducible tests → measured evidence → honest reports. A credible first step toward testing for the devices and networks many users really have.', { x: 0.8, y: 3.7, w: 9.8, h: 1.1, fontSize: 20, color: 'C9D6E8', margin: 0, isTextBox: true });
  s.addText([{ text: 'python demo-app/server.py', options: { breakLine: true } }, { text: 'python backend/run_server.py     →  http://127.0.0.1:8000' }], { x: 0.8, y: 5.05, w: 11.8, h: 0.8, fontSize: 15, color: HEX.white, fontFace: 'Courier New', margin: 0, valign: 'top', isTextBox: true });
  s.addText('[TEAM NAME]  ·  [MEMBER NAMES]  ·  [CONTACT / REPOSITORY LINK]', { x: 0.8, y: 6.3, w: 11.8, h: 0.4, fontSize: 13, color: '9FB0C8', margin: 0, isTextBox: true });
  s.addNotes('Close on the idea: testing should reflect how real users experience software. Reiterate the honesty: what we measured, how, and what we did not. Invite questions and offer a live demo — the repo runs with two commands. Fill the team placeholders before presenting.');

  await pres.writeFile({ fileName: OUT });
  await applyTheme(OUT, THEME);
  console.log('wrote', OUT);
})().catch((e) => { console.error(e); process.exit(1); });
