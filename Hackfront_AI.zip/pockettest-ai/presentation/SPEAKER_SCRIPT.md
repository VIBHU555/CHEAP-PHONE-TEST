# Speaker script — PocketTest AI (12 slides, ~12–15 min with Q&A)
Numbers in the notes come from real runs (`docs/demo-scenario-results.json`, `docs/TESTING_REPORT.json`). Replace team placeholders before presenting.

## Slide 1 — PocketTest AI
Open with the tagline. One sentence: PocketTest AI helps developers see how their web app behaves when bandwidth, latency and CPU are constrained — and gives them evidence they can act on. Team names are placeholders; replace them before presenting. Be upfront that everything shown is measured in desktop Chromium with emulated conditions, not on physical phones.

## Slide 2 — Apps get tested where conditions are easy
The problem is not that developers are careless — it is that the fast path is the only path they can easily see. In our controlled demo app, the home page loads in a few tens of milliseconds on an unconstrained browser but takes several seconds once we apply an example constrained profile. These are measured values from our own runs, not industry statistics. The profile is a test configuration; we do not claim it represents any particular Indian smartphone or carrier.

## Slide 3 — Built for the people who ship the app
Three audiences. We deliberately avoid quoting user numbers or market statistics — we do not have verified ones for this prototype. The consequences listed are plausible and well understood in the field, but they are stated as risks, not as findings from our work.

## Slide 4 — One workflow from configuration to evidence
This is the product in one line: configure, execute, measure, classify, explain, compare. The distinctive idea is provenance: every number or sentence in a report is tagged measured, simulated, estimated or hypothesis, so a developer always knows what is evidence and what is a lead. Severity comes from documented, configurable rules — never from an LLM.

## Slide 5 — The demonstrated workflow, with real numbers
These numbers are from real runs executed by scripts/run_demo_scenario.py (3 repetitions each). Standard network: 51 ms home-page load. Constrained: 6486 ms. After applying the demo app's sample optimization and re-running under the identical constrained profile: 1078 ms (-83.4%), with 6 findings resolved and 0 new. Note this improvement is for our deliberately inefficient demo app; it is not a claim about any real-world app.

## Slide 6 — Architecture and technology stack
Clean seams: UI → REST → RunManager → Engine, with the classifier, report generator and comparison as pure Python modules. SQL is isolated in one repository file, so PostgreSQL is a swap. We want to be transparent about the stack: the brief preferred FastAPI, React and pytest; our build environment had no network, so we used Flask, plain ES modules and unittest, which we could actually run and verify. The architecture is the same, so a port is mechanical.

## Slide 7 — Technical contribution: evidence you can trust
Six things that make this more than a dashboard. The two we are proudest of: enforcement is verified rather than assumed — if Chromium were not actually throttling, the report would say so — and every statement carries its provenance so a hypothesis can never masquerade as a measurement. Packet loss is the clearest example of honesty: we simulate it by aborting requests and label it simulated everywhere.

## Slide 8 — The working prototype (real screenshots)
Real screenshots captured from the running application with scripts/capture_screenshots.py, using the runs from the demo scenario. Left: one finding in the diagnostic report — a confirmed observation, evidence tagged by provenance, and possible causes tagged estimated or hypothesis, with a confidence note. Right: comparison of the constrained run before and after the sample optimization, with differences and resolved failures. The results page with its enforcement table is in docs/screenshots.

## Slide 9 — Testing methodology and actual results
The test numbers come from a real run of the full suite (python -m unittest discover -s tests): 75 implemented, 75 executed, 75 passed, 0 failed, 0 not executed. Writing the tests found two real bugs in our own code — a skip link that broke hash routing, and a hang when reading sizes of requests that never finished — both fixed. The chart is the measured median home-page load from the scenario. Small sample: 3 repetitions per run, so treat these as indicative.

## Slide 10 — Limitations, security and reliability
Be direct about limits — judges will respect it. The biggest: this is browser emulation on a laptop, not a physical Android device. We do not claim to measure memory, battery or crashes. The safeguards on the right are each covered by an automated test. One thing we have not done: the optional LLM explanation path has not been run against the live API, because the build environment had no network or key; the parsing, labelling and fallback are tested with a stub.

## Slide 11 — Roadmap and potential impact
Separate what exists from what is planned — the green column is implemented and tested today; the others are roadmap, not features. The impact statement is deliberately qualitative: we have no users, partners or adoption figures, and we are not inventing any.

## Slide 12 — Test for Everyone.
Close on the idea: testing should reflect how real users experience software. Reiterate the honesty: what we measured, how, and what we did not. Invite questions and offer a live demo — the repo runs with two commands. Fill the team placeholders before presenting.
