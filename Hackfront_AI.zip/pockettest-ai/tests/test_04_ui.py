"""UI tests: drive the real frontend in Chromium against a live API server with synthetic fixture runs."""
import subprocess
import unittest

from helpers import *  # noqa
from app.runner import RunManager

NODE_TESTS = ROOT / "tests" / "frontend" / "util.test.mjs"


class FrontendUnit(unittest.TestCase):
    def test_node_unit_tests(self):
        r = subprocess.run(["node", "--test", str(NODE_TESTS)], capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stdout[-2000:] + r.stderr[-1000:])
        self.assertIn("fail 0", r.stdout)


@unittest.skipIf(SKIP_BROWSER, "browser tests disabled")
class UiPages(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from playwright.sync_api import sync_playwright
        cls.repo = temp_repo(); cls.mgr = RunManager(cls.repo, check_reachable=False)
        cls.xss = '<img src=x onerror="window.__pwned=1"><script>window.__pwned=1</script>'
        cls.a = synthetic_run(cls.repo, mgr=cls.mgr, profile=PROFILE_CON, load=(6500,) * 3, api=(1500,) * 3, http_500=True, js_error=True, step_fail=True, optimized=False, label=cls.xss)
        cls.b = synthetic_run(cls.repo, mgr=cls.mgr, profile=PROFILE_CON, load=(900,) * 3, api=(200,) * 3, optimized=True, label="after fix")
        cls.srv = LiveServer(create_app(cls.repo, cls.mgr)); cls.srv.__enter__()
        cls.pw = sync_playwright().start(); cls.browser = cls.pw.chromium.launch()

    @classmethod
    def tearDownClass(cls):
        cls.browser.close(); cls.pw.stop(); cls.srv.__exit__()

    def open(self, hash_):
        page = self.browser.new_page(viewport={"width": 1280, "height": 900}); errs = []
        page.on("pageerror", lambda e: errs.append(str(e)))
        page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        dialogs = []; page.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
        page.goto(self.srv.url + "/#" + hash_); page.wait_for_selector("main h1"); page.wait_for_timeout(300)
        self.addCleanup(page.close)
        return page, errs

    def test_every_page_renders_without_errors(self):
        for route, title in [("/", "Dashboard"), ("/new", "New Test"), ("/history", "Test History"), ("/compare", "Run Comparison"), ("/settings", "Settings"),
                             (f"/runs/{self.a}", "Test Results"), (f"/runs/{self.a}/report", "AI Diagnostic Report"), (f"/compare?a={self.a}&b={self.b}", "Run Comparison")]:
            page, errs = self.open(route)
            self.assertIn(title, page.inner_text("main h1"), route); self.assertEqual(errs, [], route)
            self.assertEqual(page.locator("#nav a[aria-current=page]").count(), 1, route)

    def test_labels_are_escaped_no_xss(self):
        for route in ("/", "/history", f"/runs/{self.a}", f"/runs/{self.a}/report", f"/compare?a={self.a}&b={self.b}"):
            page, _ = self.open(route)
            self.assertIsNone(page.evaluate("window.__pwned"), route)

    def test_dashboard_numbers_come_from_stored_runs(self):
        page, _ = self.open("/")
        txt = page.inner_text("main")
        self.assertIn("TESTS EXECUTED\n2", txt.upper().replace("\r", "")); self.assertIn("PASSED\n1", txt.upper()); self.assertIn("FAILED\n1", txt.upper())

    def test_dashboard_empty_state(self):
        empty = temp_repo(); mgr = RunManager(empty, check_reachable=False)
        with LiveServer(create_app(empty, mgr)) as s:
            page = self.browser.new_page(); page.goto(s.url + "/#/"); page.wait_for_selector("main h1")
            self.assertIn("No test runs yet", page.inner_text("main")); self.assertGreaterEqual(page.locator(".empty").count(), 2); page.close()

    def test_report_shows_evidence_hypotheses_and_disabled_llm(self):
        page, _ = self.open(f"/runs/{self.a}/report")
        txt = page.inner_text("main")
        for frag in ("Observation", "Evidence", "Reproduction steps", "Possible causes", "Recommended next investigation", "Confidence", "hypothesis", "estimated"):
            self.assertIn(frag, txt)
        self.assertTrue(page.locator("#llm").is_disabled())          # honest: no key configured -> unavailable, not faked

    def test_compare_page_shows_warning_resolved_and_math(self):
        page, _ = self.open(f"/compare?a={self.a}&b={self.b}"); txt = page.inner_text("main")
        self.assertIn("Resolved failures", txt); self.assertIn("-86.2%", txt); self.assertIn("Demo app mode changed", txt)

    def test_incompatible_compare_shows_message(self):
        other = synthetic_run(self.repo, mgr=self.mgr, workflow_id="smoke_load")
        page, _ = self.open(f"/compare?a={self.a}&b={other}")
        page.wait_for_selector(".notice.warn"); self.assertIn("not comparable", page.inner_text("main"))

    def test_history_filter_and_select_two_to_compare(self):
        page, _ = self.open("/history")
        self.assertEqual(page.locator("tbody tr").count(), 2)
        page.select_option("#fv", "passed"); page.click("#apply"); page.wait_for_timeout(300)
        self.assertEqual(page.locator("tbody tr").count(), 1)
        page.select_option("#fv", ""); page.click("#apply"); page.wait_for_timeout(300)
        page.locator("input[type=checkbox]").nth(0).check(); page.locator("input[type=checkbox]").nth(1).check()
        self.assertFalse(page.locator("#cmpsel").is_disabled()); page.click("#cmpsel"); page.wait_for_url("**#/compare?a=*")

    def test_new_test_form_validates_and_unavailable_actions_labelled(self):
        page, _ = self.open("/new")
        page.fill("#r", "99"); page.click("#go"); page.wait_for_selector("#toast .err")
        self.assertIn("between 1 and 10", page.inner_text("#toast"))
        results, _ = self.open(f"/runs/{self.a}")
        self.assertIn("PDF export (unavailable)", results.inner_text("main"))

    def test_settings_rules_roundtrip(self):
        page, _ = self.open("/settings")
        page.fill("#r_api_latency_ms", "650"); page.click("#rf button[type=submit]"); page.wait_for_selector("#toast div")
        self.assertEqual(self.mgr.rules()["api_latency_ms"], 650.0)
        page.click("#rr"); page.wait_for_timeout(400); self.assertEqual(self.mgr.rules()["api_latency_ms"], 800)

    def test_keyboard_and_labels_basic_accessibility(self):
        page, _ = self.open("/new")
        unlabeled = page.evaluate("""() => [...document.querySelectorAll('main input, main select')].filter(e => !e.id || !document.querySelector(`label[for="${e.id}"]`)).map(e => e.id || e.outerHTML.slice(0, 60))""")
        self.assertEqual(unlabeled, [])
        page.focus(".skip")                                            # skip link must become visible when focused
        self.assertGreaterEqual(page.evaluate("document.querySelector('.skip').getBoundingClientRect().left"), 0)
        page.keyboard.press("Enter"); self.assertEqual(page.evaluate("location.hash"), "#/new")   # activating it must not break routing


if __name__ == "__main__":
    unittest.main()
