"""Classifier, report, comparison, persistence and export tests (use clearly-labelled synthetic fixtures)."""
import csv
import io
import json
import os
import unittest

from helpers import *  # noqa
from app import analysis, config
from app.classifier import classify, summarize
from app.compare import Incompatible, compare_runs, pct
from app.exports import to_csv
from app.runner import RunManager
from app.workflows import WORKFLOWS


def fixture(**kw):
    repo = temp_repo(); mgr = RunManager(repo, check_reachable=False)
    rid = synthetic_run(repo, mgr=mgr, **kw)
    return repo, mgr, rid


class Classification(unittest.TestCase):
    def test_clean_run_has_no_findings_and_passes(self):
        repo, _, rid = fixture()
        run = repo.get_run(rid)
        self.assertEqual(repo.run_data(rid)["findings"], []); self.assertEqual(run["verdict"], "passed")

    def test_slow_api_threshold_message_and_evidence(self):
        repo, _, rid = fixture(load=(100,) * 5, api=(900, 950, 1000, 400, 1200))
        f = [x for x in repo.run_data(rid)["findings"] if x["rule_id"] == "SLOW_API"][0]
        self.assertEqual(f["severity"], "medium")
        self.assertEqual((f["evidence"]["exceeding"], f["evidence"]["total"]), (4, 5))
        self.assertIn("4 of 5", f["title"])

    def test_below_ratio_not_flagged(self):
        repo, _, rid = fixture(load=(100,) * 5, api=(900, 400, 300, 350, 320))   # 1 of 5 over
        self.assertFalse([x for x in repo.run_data(rid)["findings"] if x["rule_id"] == "SLOW_API"])

    def test_extreme_latency_escalates_to_high(self):
        repo, _, rid = fixture(api=(5000, 5200, 5100))
        f = [x for x in repo.run_data(rid)["findings"] if x["rule_id"] == "SLOW_API"][0]
        self.assertEqual(f["severity"], "high")

    def test_noncore_step_failing_always_is_high_not_critical(self):
        repo, _, rid = fixture(step_fail=True)
        f = [x for x in repo.run_data(rid)["findings"] if x["rule_id"] == "STEP_FAILED"][0]
        self.assertEqual(f["severity"], "high"); self.assertIn("timed out in 3 of 3", f["title"])
        self.assertEqual(repo.get_run(rid)["verdict"], "failed")

    def test_core_step_failing_always_is_critical(self):
        repo = temp_repo(); target = config.builtin_targets()[0]
        rid = repo.create_run(label="x", target=target, profile=PROFILE_STD, workflow_id="smoke_load", repetitions=2, rules=config.default_rules(), target_meta={})
        for rep in (1, 2):
            repo.add_step(rid, rep, {"step_id": "load_home", "step_name": "Load home page", "core": True, "status": "failed", "duration_ms": 10,
                                     "error": "net::ERR_CONNECTION_REFUSED", "pending": None, "started_at": "t"})
        RunManager(repo, check_reachable=False).finalize(rid)
        f = repo.run_data(rid)["findings"]
        self.assertEqual([x["severity"] for x in f], ["critical"]); self.assertIn("could not complete", f[0]["title"])

    def test_flaky_step_is_medium(self):
        run = {"profile": PROFILE_STD, "target_id": "t", "target_url": "u", "workflow_id": "w", "repetitions": 4, "target_meta": {}}
        steps = [{"step_id": "home", "step_name": "Home", "core": False, "status": "passed" if i else "failed", "error": "boom", "pending": None, "duration_ms": 1} for i in range(4)]
        f = classify(run, {"steps": steps, "requests": [], "page_metrics": [], "js_errors": []}, config.default_rules(), WORKFLOWS["shop_checkout"])
        self.assertEqual(f[0]["severity"], "medium")

    def test_failed_request_js_error_and_page_rules(self):
        repo, _, rid = fixture(load=(4000, 4100, 3900), http_500=True, js_error=True)
        rules = {f["rule_id"]: f for f in repo.run_data(rid)["findings"]}
        self.assertEqual(rules["REQUEST_FAILED"]["severity"], "high")
        self.assertEqual(rules["JS_ERROR"]["severity"], "medium")
        self.assertEqual(rules["SLOW_PAGE_LOAD"]["severity"], "medium")
        self.assertEqual(rules["LARGE_TRANSFER"]["severity"], "low")

    def test_severity_rules_are_configurable(self):
        repo = temp_repo(); target = config.builtin_targets()[0]
        rules = config.default_rules(); rules.update(severity_js_error="low", page_load_ms=200, fail_on_severity=["critical"])
        rid = repo.create_run(label="x", target=target, profile=PROFILE_STD, workflow_id="shop_checkout", repetitions=1, rules=rules, target_meta={})
        repo.add_step(rid, 1, {"step_id": "home", "step_name": "Home", "core": True, "status": "passed", "duration_ms": 5, "error": None, "pending": None, "started_at": "t"})
        repo.add_page_metric(rid, 1, "home", {"path": "/", "load_ms": 250, "fcp_ms": 1, "lcp_ms": 1, "dom_content_loaded_ms": 1, "nav_duration_ms": 1, "resource_count": 1, "transfer_bytes": 1})
        repo.add_js_errors(rid, 1, "home", [{"kind": "exception", "message": "oops"}])
        RunManager(repo, check_reachable=False).finalize(rid)
        by = {f["rule_id"]: f["severity"] for f in repo.run_data(rid)["findings"]}
        self.assertEqual(by["JS_ERROR"], "low"); self.assertEqual(by["SLOW_PAGE_LOAD"], "medium")
        self.assertEqual(repo.get_run(rid)["verdict"], "passed")   # custom fail_on_severity honoured


class Reports(unittest.TestCase):
    def setUp(self):
        self.repo, self.mgr, self.rid = fixture(profile=PROFILE_CON, load=(6500, 6600, 6400), api=(1400, 1500, 1450), http_500=True, js_error=True, step_fail=True)
        self.rep = self.repo.get_report(self.rid)

    def test_report_persisted_and_complete(self):
        self.assertEqual(self.rep["generator"], "deterministic")
        self.assertTrue(self.rep["findings"])
        for f in self.rep["findings"]:
            for key in ("title", "severity", "evidence", "operation", "reproduction_steps", "possible_causes", "recommended_investigation", "confidence_note", "observation"):
                self.assertIn(key, f); self.assertTrue(f[key] or key == "possible_causes", key)

    def test_hypotheses_are_labelled_and_observations_confirmed(self):
        for f in self.rep["findings"]:
            self.assertEqual(f["observation_status"], "confirmed (measured)")
            for c in f["possible_causes"]:
                self.assertIn(c["basis"], ("measured", "estimated", "hypothesis", "simulated")); self.assertIn(c["confidence"], ("high", "medium", "low"))
        txt = json.dumps(self.rep).lower()
        import re
        self.assertIsNone(re.search(r"root cause is (?!not)", txt))       # never asserts a root cause
        self.assertNotIn("the database is", txt); self.assertNotIn("caused by the database", txt)

    def test_server_vs_network_split_uses_server_timing(self):
        slow = [f for f in self.rep["findings"] if f["rule_id"] == "SLOW_API"][0]
        t = " ".join(c["text"] for c in slow["possible_causes"])
        self.assertIn("outside server processing", t); self.assertIn("estimated", json.dumps(slow["possible_causes"]))

    def test_report_states_what_is_not_measured(self):
        self.assertTrue(any("RAM" in x for x in self.rep["measurement_notes"]["not_measured"]))

    def test_llm_failure_falls_back_to_deterministic(self):
        def boom(prompt): raise RuntimeError("network down")
        out = analysis.llm_enhance(json.loads(json.dumps(self.rep)), boom)
        self.assertEqual(out["llm"]["status"], "error"); self.assertEqual(out["generator"], "deterministic")
        self.assertEqual(len(out["findings"]), len(self.rep["findings"]))

    def test_llm_output_is_labelled_and_cannot_change_severity(self):
        first = self.rep["findings"][0]
        reply = json.dumps({"summary": "S", "findings": [{"id": first["finding_id"], "explanation": "It may be X.", "additional_hypotheses": ["could be Y"], "severity": "low"}]})
        out = analysis.llm_enhance(json.loads(json.dumps(self.rep)), lambda p: "```json\n" + reply + "\n```")
        f0 = out["findings"][0]
        self.assertEqual(f0["severity"], first["severity"]); self.assertIn("not confirmed", f0["ai_explanation"]["label"])
        self.assertEqual(out["generator"], "deterministic+llm"); self.assertIn("not confirmed", out["ai_summary"]["label"])

    def test_llm_garbage_output_handled(self):
        out = analysis.llm_enhance(json.loads(json.dumps(self.rep)), lambda p: "not json at all")
        self.assertEqual(out["llm"]["status"], "error")

    def test_llm_requires_key_via_api(self):
        os.environ.pop("ANTHROPIC_API_KEY", None)
        c = create_app(self.repo, self.mgr).test_client()
        self.assertEqual(c.post(f"/api/runs/{self.rid}/report/regenerate", json={"use_llm": True}).status_code, 400)
        self.assertEqual(c.post(f"/api/runs/{self.rid}/report/regenerate", json={"use_llm": False}).status_code, 200)

    def test_no_secret_in_prompt(self):
        os.environ["ANTHROPIC_API_KEY"] = "sk-test-SECRET"
        seen = []
        try:
            analysis.llm_enhance(json.loads(json.dumps(self.rep)), lambda p: seen.append(p) or "{}")
        finally:
            os.environ.pop("ANTHROPIC_API_KEY")
        self.assertNotIn("SECRET", seen[0])


class Comparison(unittest.TestCase):
    def test_percent_change_math(self):
        self.assertEqual(pct(100, 150), 50.0); self.assertEqual(pct(200, 100), -50.0)
        self.assertIsNone(pct(0, 10)); self.assertIsNone(pct(None, 10)); self.assertIsNone(pct(10, None))

    def setUp(self):
        self.repo = temp_repo(); self.mgr = RunManager(self.repo, check_reachable=False)
        self.a = synthetic_run(self.repo, mgr=self.mgr, profile=PROFILE_CON, load=(6500,) * 3, api=(1500,) * 3, http_500=True, js_error=True, optimized=False, label="base")
        self.b = synthetic_run(self.repo, mgr=self.mgr, profile=PROFILE_CON, load=(900,) * 3, api=(200,) * 3, optimized=True, label="new")
        self.c = create_app(self.repo, self.mgr).test_client()

    def test_compare_differences_new_and_resolved(self):
        j = self.c.get(f"/api/compare?a={self.a}&b={self.b}").get_json()
        self.assertEqual(j["pages"]["/"]["load_ms"]["abs"], -5600); self.assertEqual(j["pages"]["/"]["load_ms"]["pct"], -86.2)
        self.assertEqual(j["endpoints"]["GET /api/products"]["median_ms"]["abs"], -1300)
        self.assertTrue(any("JavaScript" in f["title"] for f in j["resolved_failures"])); self.assertEqual(j["new_failures"], [])
        self.assertEqual(j["warnings"], []); self.assertTrue(any("optimized" in n for n in j["notes"]))

    def test_regressions_detected_when_reversed(self):
        j = self.c.get(f"/api/compare?a={self.b}&b={self.a}").get_json()
        self.assertTrue(any(r["metric"] == "/ load_ms" for r in j["regressions"])); self.assertTrue(j["new_failures"])

    def test_warning_when_conditions_differ(self):
        std = synthetic_run(self.repo, mgr=self.mgr, profile=PROFILE_STD, load=(100,) * 3, label="std")
        j = self.c.get(f"/api/compare?a={std}&b={self.a}").get_json()
        self.assertTrue(j["warnings"] and "differ" in j["warnings"][0])

    def test_incompatible_workflows_refused(self):
        other = synthetic_run(self.repo, mgr=self.mgr, workflow_id="smoke_load")
        r = self.c.get(f"/api/compare?a={self.a}&b={other}")
        self.assertEqual(r.status_code, 409); self.assertEqual(r.get_json()["error"]["code"], "incompatible_runs")

    def test_bad_compare_requests(self):
        self.assertEqual(self.c.get(f"/api/compare?a={self.a}&b={self.a}").status_code, 400)
        self.assertEqual(self.c.get("/api/compare?a=zzz&b=yyy").status_code, 404)
        self.assertEqual(self.c.get("/api/compare").status_code, 400)


class PersistenceAndExport(unittest.TestCase):
    def test_results_survive_restart(self):
        repo, _, rid = fixture(js_error=True, label="persist me")
        from app.db import Repo
        again = Repo(repo.path)                       # new connection = simulated restart
        run = again.get_run(rid)
        self.assertEqual(run["label"], "persist me"); self.assertEqual(run["status"], "completed")
        self.assertTrue(again.get_report(rid)["findings"]); self.assertTrue(again.run_data(rid)["requests"])

    def test_interrupted_runs_marked_failed_on_startup(self):
        repo = temp_repo(); target = config.builtin_targets()[0]
        rid = repo.create_run(label="x", target=target, profile=PROFILE_STD, workflow_id="smoke_load", repetitions=1, rules={}, target_meta={})
        RunManager(repo, check_reachable=False)
        self.assertEqual(repo.get_run(rid)["status"], "failed")

    def test_history_filters(self):
        repo, mgr, a = fixture(label="ok-run")
        b = synthetic_run(repo, mgr=mgr, step_fail=True, label="bad-run")
        c = create_app(repo, mgr).test_client()
        self.assertEqual([r["id"] for r in c.get("/api/runs?verdict=failed").get_json()], [b])
        self.assertEqual([r["id"] for r in c.get("/api/runs?verdict=passed").get_json()], [a])
        self.assertEqual(len(c.get("/api/runs?status=completed").get_json()), 2)
        self.assertEqual(c.get("/api/runs?from=2999-01-01").get_json(), [])
        self.assertEqual(c.delete(f"/api/runs/{a}").status_code, 200); self.assertEqual(c.get(f"/api/runs/{a}").status_code, 404)

    def test_json_export(self):
        repo, mgr, rid = fixture(js_error=True)
        r = create_app(repo, mgr).test_client().get(f"/api/runs/{rid}/export?format=json")
        j = json.loads(r.data)
        self.assertEqual(j["export_format"], "pockettest-ai/run@1"); self.assertEqual(j["run"]["id"], rid)
        self.assertTrue(j["requests"] and j["findings"] and j["report"])

    def test_csv_export_all_parts_and_formula_injection(self):
        repo, mgr, rid = fixture(js_error=True)
        repo.add_js_errors(rid, 1, "home", [{"kind": "exception", "message": "=cmd|' /C calc'!A0"}])
        c = create_app(repo, mgr).test_client()
        for part in ("findings", "requests", "steps", "page_metrics", "js_errors"):
            r = c.get(f"/api/runs/{rid}/export?format=csv&part={part}")
            self.assertEqual(r.status_code, 200); rows = list(csv.reader(io.StringIO(r.data.decode())))
            self.assertGreaterEqual(len(rows), 2, part)
        rows = list(csv.reader(io.StringIO(c.get(f"/api/runs/{rid}/export?format=csv&part=js_errors").data.decode())))
        self.assertTrue(any(r[3].startswith("'=") for r in rows[1:]))
        self.assertEqual(c.get(f"/api/runs/{rid}/export?format=csv&part=evil").status_code, 400)
        self.assertEqual(c.get(f"/api/runs/{rid}/export?format=xml").status_code, 400)


if __name__ == "__main__":
    unittest.main()
