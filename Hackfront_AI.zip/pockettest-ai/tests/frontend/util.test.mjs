// Run with: node --test tests/frontend
import test from 'node:test';
import assert from 'node:assert/strict';
import { esc, fmtMs, fmtBytes, fmtPct, median, histogram, deltaClass, timeAgo, profileSummary } from '../../frontend/js/util.js';
import { barChart, lineChart, donut, groupedBars } from '../../frontend/js/charts.js';

test('esc neutralises HTML/JS injection', () => {
  assert.equal(esc('<img src=x onerror="a()">'), '&lt;img src=x onerror=&quot;a()&quot;&gt;');
  assert.equal(esc(null), ''); assert.equal(esc("it's"), 'it&#39;s');
});
test('formatters', () => {
  assert.equal(fmtMs(null), 'n/a'); assert.equal(fmtMs(123.4), '123 ms'); assert.equal(fmtMs(12500), '12.5 s');
  assert.equal(fmtBytes(500), '500 B'); assert.equal(fmtBytes(2048), '2 KB'); assert.equal(fmtBytes(3 * 1048576), '3.00 MB'); assert.equal(fmtBytes(null), 'n/a');
  assert.equal(fmtPct(null), '—'); assert.equal(fmtPct(12.34), '+12.3%'); assert.equal(fmtPct(-5), '-5.0%');
});
test('median', () => {
  assert.equal(median([3, 1, 2]), 2); assert.equal(median([1, 2, 3, 4]), 2.5); assert.equal(median([]), null); assert.equal(median([null, 5]), 5);
});
test('histogram', () => {
  assert.deepEqual(histogram([]), []);
  const h = histogram([1, 2, 3, 10], 3); assert.equal(h.length, 3); assert.equal(h.reduce((a, b) => a + b.count, 0), 4); assert.equal(h[2].count, 1);
  assert.equal(histogram([5, 5, 5])[0].count, 3);
});
test('deltaClass: lower is better', () => {
  assert.equal(deltaClass(-20), 'good'); assert.equal(deltaClass(20), 'bad'); assert.equal(deltaClass(0.2), 'flat'); assert.equal(deltaClass(null), 'flat');
});
test('timeAgo and profileSummary', () => {
  const now = Date.parse('2026-01-01T01:00:00Z');
  assert.equal(timeAgo('2026-01-01T00:59:30Z', now), '30s ago'); assert.equal(timeAgo('2026-01-01T00:00:00Z', now), '1h ago');
  assert.match(profileSummary({ download_kbps: 1000, latency_ms: 150, packet_loss_pct: 0, cpu_slowdown: 4 }), /1000 kbps down · 150 ms latency · 0% loss \(simulated\) · 4x CPU/);
  assert.match(profileSummary({}), /unlimited down/);
});
test('charts show explicit empty states instead of fake data', () => {
  assert.match(barChart([]), /class="empty"/); assert.match(barChart([{ label: 'a', value: null }]), /class="empty"/);
  assert.match(lineChart([{ label: 'a', value: 1 }]), /At least two completed runs/); assert.match(donut([{ label: 'x', value: 0, color: 'red' }]), /class="empty"/);
  assert.match(groupedBars([]), /class="empty"/);
});
test('charts render accessible, escaped SVG', () => {
  const svg = barChart([{ label: '<b>x</b>', value: 5 }, { label: 'y', value: 10 }], { title: 'T' });
  assert.match(svg, /role="img" aria-label="T"/); assert.ok(!svg.includes('<b>x</b>')); assert.match(svg, /&lt;b&gt;/);
  assert.match(lineChart([{ label: 'a', value: 1 }, { label: 'b', value: 3 }]), /<path /);
  assert.match(donut([{ label: 'p', value: 2, color: 'green' }, { label: 'f', value: 1, color: 'red' }]), /<circle/);
  const g = groupedBars([{ label: '/', a: 100, b: 50 }]); assert.match(g, /Baseline/); assert.match(g, /<rect/);
});
