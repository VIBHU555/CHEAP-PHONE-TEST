"""Integration tests: real Chromium (Playwright) against the local demo app. Skipped when PT_SKIP_BROWSER=1."""
import time
import unittest
from unittest import mock

from flask import Flask

from helpers import *  # noqa
from app import config, engine
from app.runner import RunManager
from app.workflows import WORKFLOWS


@unittest.skipIf(SKIP_BROWSER, "browser tests disabled")
class BrowserIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.demo_srv, cls.demo = make_demo()
        cls.demo_srv.__enter__()
        cls._orig_url = config.DEMO_URL
        config.DEMO_URL = cls.demo_srv.url

    @classmethod
    def tearDownClass(cls):
        config.DEMO_URL = cls._orig_url
        cls.demo_srv.__exit__()

    def setUp(self):
        self.demo.STATE["optimized"] = False
        self.repo = temp_repo()
        self.mgr = RunManager(self.repo, check_reachable=True)
        self.client = create_app(self.repo, self.mgr).test_client()

    def run_test(self, profile="standard", workflow="shop_checkout", reps=1, timeout=180):
        rid = self.mgr.start({"target_id": "demo-shop", "profile_id": profile, "workflow_id": workflow, "repetitions": reps, "label": f"{workflow}/{profile}"})
        self.mgr.wait(rid, timeout)
        return rid, self.repo.get_run(rid), self.repo.run_data(rid)

    # ------------------------------------------------------------ successful execution + measurements
    def test_successful_execution_records_real_measurements(self):
        rid, run, data = self.run_test()
        self.assertEqual(run["status"], "completed", run["error"])
        self.assertEqual(len(data["steps"]), 5)
        by_step = {s["step_id"]: s for s in data["steps"]}
        self.assertEqual([by_step[k]["status"] for k in ("home", "products", "checkout", "about")], ["passed"] * 4)
        home = [m for m in data["page_metrics"] if m["path"] == "/"][0]
        for k in ("nav_duration_ms", "dom_content_loaded_ms", "load_ms", "fcp_ms", "transfer_bytes"):
            self.assertIsNotNone(home[k], k)
        self.assertGreater(home["transfer_bytes"], 500_000)                     # unoptimized bundle + hero image
        api = [r for r in data["requests"] if r["path"] == "/api/products"][0]
        self.assertTrue(api["is_api"]); self.assertGreater(api["duration_ms"], 400)  # server sleeps 450 ms
        self.assertAlmostEqual(api["server_ms"], 450, delta=120)                 # server-side timing recorded separately
        self.assertEqual(run["environment"]["enforcement"][0]["status"], "not_requested")  # honest: unmodified session
        self.assertIn("Chromium", run["environment"]["browser"])
        self.assertEqual(engine.open_browser_count(), 0)
        # persistence + export + report via the API
        self.assertEqual(self.client.get(f"/api/runs/{rid}").get_json()["run"]["status"], "completed")
        self.assertTrue(self.client.get(f"/api/runs/{rid}/report").get_json()["report"]["findings"])
        self.assertIn("rule_id", self.client.get(f"/api/runs/{rid}/export?format=csv").data.decode())

    def test_deliberate_demo_faults_are_detected(self):
        _, run, data = self.run_test()
        rules = {f["rule_id"] for f in data["findings"]}
        self.assertTrue({"JS_ERROR", "REQUEST_FAILED", "STEP_FAILED"} <= rules, rules)
        step = [f for f in data["findings"] if f["rule_id"] == "STEP_FAILED"][0]
        self.assertIn("timed out", step["title"]); self.assertEqual(step["severity"], "high")
        self.assertIn("GET /api/report", step["evidence"]["requests_pending_at_failure"])
        js = [f for f in data["findings"] if f["rule_id"] == "JS_ERROR"][0]
        self.assertIn("render", js["evidence"]["message"])
        self.assertEqual(run["verdict"], "failed")

    # ------------------------------------------------------------ failed request detection
    def test_failed_request_detection_via_api_workflow(self):
        _, run, data = self.run_test(workflow="api_health", reps=2)
        self.assertEqual(run["status"], "completed")
        recs = [r for r in data["requests"] if r["path"] == "/api/recommendations"]
        self.assertEqual(len(recs), 2); self.assertTrue(all(r["failed"] and r["status"] == 500 for r in recs))
        f = [x for x in data["findings"] if x["rule_id"] == "REQUEST_FAILED"][0]
        self.assertIn("2 of 2", f["title"]); self.assertEqual(f["severity"], "high")

    # ------------------------------------------------------------ timeout handling
    def test_timeout_is_enforced_and_recorded(self):
        wf = {"id": "t", "name": "t", "steps": [{"id": "report", "name": "Generate report", "type": "click_wait", "path": "/reports", "click": "#gen-report",
                                                 "wait_selector": "#report-ready", "timeout_ms": 1500, "core": False}]}

        class Sink:
            steps = []
            add_step = lambda s, rep, x: Sink.steps.append(x)
            add_requests = add_page_metric = add_js_errors = lambda *a: None
        t0 = time.time()
        engine.run_workflow(origin=self.demo_srv.url, profile=PROFILE_STD, workflow=wf, repetitions=1, seed=1, sink=Sink(), on_event=lambda *a, **k: None, should_cancel=lambda: False)
        self.assertLess(time.time() - t0, 8)                                      # did not wait for the 9 s endpoint
        s = Sink.steps[0]
        self.assertEqual(s["status"], "timeout"); self.assertIn("1500", s["error"]); self.assertEqual(s["pending"], ["GET /api/report"])
        self.assertEqual(engine.open_browser_count(), 0)

    # ------------------------------------------------------------ constrained network + optimisation loop
    def test_constrained_network_enforced_then_optimisation_compared(self):
        std, _, std_data = self.run_test("standard", "smoke_load")
        con, con_run, con_data = self.run_test("constrained", "smoke_load")
        enf = {e["setting"]: e for e in con_run["environment"]["enforcement"]}
        self.assertEqual(enf["download_kbps"]["status"], "applied"); self.assertIn("CDP", enf["download_kbps"]["method"])
        self.assertTrue(enf["download_kbps"]["verification"].startswith("consistent"), enf["download_kbps"])
        self.assertEqual(enf["packet_loss_pct"]["status"], "not_requested")
        load_std = [m["load_ms"] for m in std_data["page_metrics"]][0]; load_con = [m["load_ms"] for m in con_data["page_metrics"]][0]
        self.assertLess(load_std, 2000); self.assertGreater(load_con, 3000); self.assertGreater(load_con, 5 * load_std)
        self.assertIn("SLOW_PAGE_LOAD", {f["rule_id"] for f in con_data["findings"]})
        # profile difference must be surfaced as a warning
        self.assertTrue(self.client.get(f"/api/compare?a={std}&b={con}").get_json()["warnings"])
        # apply the sample optimisation and re-run under identical conditions
        self.assertEqual(self.client.post("/api/demo/mode", json={"optimized": True}).status_code, 200)
        opt, opt_run, opt_data = self.run_test("constrained", "smoke_load")
        self.assertTrue(opt_run["target_meta"]["optimized"])
        c = self.client.get(f"/api/compare?a={con}&b={opt}").get_json()
        self.assertEqual(c["warnings"], [])
        self.assertLess(c["pages"]["/"]["load_ms"]["pct"], -50)
        self.assertTrue(any("load time" in f["title"] for f in c["resolved_failures"]))
        self.assertEqual(c["new_failures"], [])

    # ------------------------------------------------------------ simulated packet loss is labelled as simulated
    def test_packet_loss_is_simulated_and_labelled(self):
        prof = self.client.post("/api/profiles", json={"name": "Total loss", "packet_loss_pct": 100}).get_json()
        _, run, data = self.run_test(prof["id"], "smoke_load")
        enf = {e["setting"]: e for e in run["environment"]["enforcement"]}
        self.assertEqual(enf["packet_loss_pct"]["status"], "simulated"); self.assertIn("NOT real packet loss", enf["packet_loss_pct"]["method"])
        sim = [r for r in data["requests"] if r["simulated_fault"]]
        self.assertGreaterEqual(len(sim), 3); self.assertTrue(all("simulated" in r["failure_text"] for r in sim))
        self.assertTrue(any("injected" in f["title"] for f in data["findings"] if f["rule_id"] == "REQUEST_FAILED"))

    # ------------------------------------------------------------ safeguards
    def test_cross_origin_requests_from_page_are_blocked(self):
        other = Flask("other"); other.get("/x.png")(lambda: ("x", 200))
        with LiveServer(other) as o:
            page = Flask("page")
            page.get("/")(lambda: f"<html><body><img src='{o.url}/x.png'><script src='http://169.254.169.254/evil.js'></script>hello</body></html>")
            with LiveServer(page) as p:
                out = engine.run_workflow(origin=p.url, profile=PROFILE_STD, workflow=WORKFLOWS["smoke_load"], repetitions=1, seed=1,
                                          sink=mock.MagicMock(), on_event=lambda *a, **k: None, should_cancel=lambda: False)
        self.assertEqual(out["environment"]["blocked_requests"], 2)

    def test_unreachable_target_yields_critical_finding(self):
        config.DEMO_URL = f"http://127.0.0.1:{free_port()}"
        try:
            mgr = RunManager(self.repo, check_reachable=False)
            rid = mgr.start({"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "smoke_load", "repetitions": 1}); mgr.wait(rid, 60)
        finally:
            config.DEMO_URL = self.demo_srv.url
        run, data = self.repo.get_run(rid), self.repo.run_data(rid)
        self.assertEqual(run["status"], "completed"); self.assertEqual(run["verdict"], "failed")
        self.assertEqual(data["steps"][0]["status"], "failed")
        self.assertEqual(data["findings"][0]["severity"], "critical")             # core workflow cannot complete
        self.assertIn("could not complete", data["findings"][0]["title"])
        self.assertTrue(any("CONNECTION_REFUSED" in (r["failure_text"] or "") for r in data["requests"]))   # the evidence

    def test_start_refuses_unreachable_target_up_front(self):
        config.DEMO_URL = f"http://127.0.0.1:{free_port()}"
        try:
            r = self.client.post("/api/runs", json={"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "smoke_load"})
        finally:
            config.DEMO_URL = self.demo_srv.url
        self.assertEqual(r.status_code, 400); self.assertIn("not reachable", r.get_json()["error"]["message"])

    # ------------------------------------------------------------ cleanup of failed sessions
    def test_browser_is_cleaned_up_after_unexpected_engine_error(self):
        with mock.patch.object(engine, "_enforce", side_effect=RuntimeError("boom")):
            _, run, _ = self.run_test(workflow="smoke_load")
        self.assertEqual(run["status"], "failed"); self.assertIn("boom", run["error"])
        self.assertEqual(engine.open_browser_count(), 0)
        self.assertFalse(engine.LAST_BROWSER.is_connected())
        self.assertEqual(self.mgr.sem._value, 1)                                  # slot released: next run can start

    def test_unenforceable_constraint_aborts_instead_of_running_unconstrained(self):
        with mock.patch.object(engine, "_enforce", side_effect=engine.EnforcementError("CDP unavailable")):
            _, run, data = self.run_test("constrained", "smoke_load")
        self.assertEqual(run["status"], "failed"); self.assertIn("could not be enforced", run["error"]); self.assertEqual(data["steps"], [])
        self.assertFalse(engine.LAST_BROWSER.is_connected())

    def test_cancellation_stops_run_and_cleans_up(self):
        rid = self.mgr.start({"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "shop_checkout", "repetitions": 5})
        time.sleep(2.5); self.assertTrue(self.mgr.cancel(rid)); self.mgr.wait(rid, 60)
        self.assertEqual(self.repo.get_run(rid)["status"], "cancelled")
        self.assertEqual(engine.open_browser_count(), 0); self.assertFalse(engine.LAST_BROWSER.is_connected())

    def test_second_run_rejected_while_one_is_active(self):
        rid = self.mgr.start({"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "shop_checkout", "repetitions": 5})
        try:
            r = self.client.post("/api/runs", json={"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "smoke_load"})
            self.assertEqual(r.status_code, 429)
        finally:
            self.mgr.cancel(rid); self.mgr.wait(rid, 60)


if __name__ == "__main__":
    unittest.main()
