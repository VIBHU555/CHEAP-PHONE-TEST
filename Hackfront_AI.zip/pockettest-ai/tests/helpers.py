"""Shared test helpers. Synthetic fixtures here are TEST DATA ONLY and are never shown as real results."""
import os
import socket
import sys
import tempfile
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "demo-app"))

from werkzeug.serving import make_server  # noqa: E402

from app import config  # noqa: E402
from app.db import Repo  # noqa: E402
from app.runner import RunManager  # noqa: E402
from app.server import create_app  # noqa: E402

import logging
logging.getLogger("werkzeug").setLevel(logging.ERROR)
SKIP_BROWSER = os.environ.get("PT_SKIP_BROWSER") == "1"


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class LiveServer:
    """Run a WSGI app on a free port in a thread."""

    def __init__(self, app):
        self.port = free_port()
        self.srv = make_server("127.0.0.1", self.port, app, threaded=True)
        self.thread = threading.Thread(target=self.srv.serve_forever, daemon=True)

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}"

    def __enter__(self):
        self.thread.start(); return self

    def __exit__(self, *a):
        self.srv.shutdown(); self.thread.join(5)


def make_demo():
    import server as demo
    demo.STATE["optimized"] = False
    return LiveServer(demo.app), demo


def temp_repo():
    d = tempfile.mkdtemp(prefix="pt-test-")
    return Repo(os.path.join(d, "t.sqlite3"))


PROFILE_STD = next(p for p in config.BUILTIN_PROFILES if p["id"] == "standard")
PROFILE_CON = next(p for p in config.BUILTIN_PROFILES if p["id"] == "constrained")


def synthetic_run(repo, *, profile=PROFILE_STD, workflow_id="shop_checkout", load=(100, 110, 120), api=(300, 320, 310), label="synthetic fixture",
                  optimized=None, step_fail=False, js_error=False, http_500=False, mgr=None):
    """Insert a fully formed run (test fixture) and finalize it through the real classifier/report code."""
    target = config.builtin_targets()[0]
    rules = config.default_rules()
    rid = repo.create_run(label=label, target=target, profile=profile, workflow_id=workflow_id, repetitions=len(load), rules=rules,
                          target_meta={"optimized": optimized} if optimized is not None else {})
    for rep, (l, a) in enumerate(zip(load, api), start=1):
        for sid, name, core in (("home", "Load home page", True), ("products", "Open product list", True), ("report", "Generate sales report", False)):
            failed = step_fail and sid == "report"
            repo.add_step(rid, rep, {"step_id": sid, "step_name": name, "core": core, "status": "timeout" if failed else "passed",
                                     "duration_ms": 6000 if failed else 50, "error": "Timeout 6000ms exceeded" if failed else None,
                                     "pending": ["GET /api/report"] if failed else None, "started_at": "2026-01-01T00:00:00Z"})
        repo.add_page_metric(rid, rep, "home", {"path": "/", "load_ms": l, "fcp_ms": l / 2, "lcp_ms": l / 2, "dom_content_loaded_ms": l, "nav_duration_ms": l,
                                                "resource_count": 4, "transfer_bytes": 700_000 if l > 1000 else 20_000})
        reqs = [{"method": "GET", "path": "/api/products", "resource_type": "fetch", "status": 200, "failed": False, "duration_ms": a,
                 "transfer_bytes": 120_000, "server_ms": 450.0, "is_api": True, "source": "fixture"},
                {"method": "GET", "path": "/static/app.bundle.js", "resource_type": "script", "status": 200, "failed": False, "duration_ms": 10,
                 "transfer_bytes": 380_000 if l > 1000 else 10_000, "server_ms": 0.0, "is_api": False}]
        if http_500:
            reqs.append({"method": "GET", "path": "/api/recommendations", "resource_type": "fetch", "status": 500, "failed": True, "failure_text": "HTTP 500",
                         "duration_ms": None, "transfer_bytes": 67, "server_ms": 0.1, "is_api": True})
        repo.add_requests(rid, rep, "products", reqs)
        if js_error:
            repo.add_js_errors(rid, rep, "home", [{"kind": "exception", "message": "TypeError: x is null"}])
    repo.update_run(rid, status="running", environment={"enforcement": [], "browser": "fixture"})
    (mgr or RunManager(repo, check_reachable=False)).finalize(rid)
    return rid
