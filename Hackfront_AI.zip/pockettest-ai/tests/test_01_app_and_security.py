import json
import unittest

from helpers import *  # noqa
from app import config, security
from app.runner import RunManager
from app.security import TargetRejected, is_request_allowed, validate_target_url

REG = ["http://127.0.0.1:5055"]


class AppStartup(unittest.TestCase):
    def setUp(self):
        self.repo = temp_repo()
        self.app = create_app(self.repo, RunManager(self.repo, check_reachable=False))
        self.c = self.app.test_client()

    def test_application_startup_and_health(self):
        r = self.c.get("/api/health")
        self.assertEqual(r.status_code, 200)
        j = r.get_json()
        self.assertEqual(j["status"], "ok"); self.assertTrue(j["database"]); self.assertIn("llm_configured", j)

    def test_catalogues(self):
        self.assertEqual({p["id"] for p in self.c.get("/api/profiles").get_json()} >= {"standard", "constrained", "high_latency", "intermittent"}, True)
        self.assertIn("shop_checkout", [w["id"] for w in self.c.get("/api/workflows").get_json()])
        self.assertEqual(self.c.get("/api/targets").get_json()[0]["id"], "demo-shop")

    def test_frontend_served(self):
        r = self.c.get("/")
        self.assertEqual(r.status_code, 200); self.assertIn(b"PocketTest AI", r.data)
        self.assertEqual(self.c.get("/js/app.js").status_code, 200)
        self.assertEqual(self.c.get("/api/nope").status_code, 404)

    def test_stats_empty_state(self):
        j = self.c.get("/api/stats").get_json()
        self.assertEqual((j["total_runs"], j["passed"], j["failed"], j["total_issues"]), (0, 0, 0, 0))


class ConfigValidation(unittest.TestCase):
    def setUp(self):
        self.repo = temp_repo()
        self.c = create_app(self.repo, RunManager(self.repo, check_reachable=False)).test_client()

    def post(self, body, raw=None):
        return self.c.post("/api/runs", data=raw if raw is not None else json.dumps(body), content_type="application/json")

    def test_invalid_inputs_rejected(self):
        ok = {"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "smoke_load", "repetitions": 1}
        cases = [({**ok, "target_id": "nope"}, "Unknown target"), ({**ok, "profile_id": "nope"}, "Unknown profile"),
                 ({**ok, "workflow_id": "nope"}, "workflow"), ({**ok, "repetitions": 0}, "repetitions"), ({**ok, "repetitions": 11}, "repetitions"),
                 ({**ok, "repetitions": True}, "repetitions"), ({**ok, "repetitions": "3"}, "repetitions"), ({**ok, "label": "x" * 200}, "label")]
        for body, frag in cases:
            r = self.post(body)
            self.assertEqual(r.status_code, 400, body); self.assertIn(frag.lower(), r.get_json()["error"]["message"].lower())

    def test_malformed_json_and_non_object(self):
        self.assertEqual(self.post(None, raw="{not json").status_code, 400)
        self.assertEqual(self.post(None, raw="[1,2]").status_code, 400)

    def test_oversized_body(self):
        self.assertEqual(self.post(None, raw="x" * 300_000).status_code, 413)

    def test_rule_and_profile_validation(self):
        self.assertEqual(self.c.put("/api/settings/rules", json={"api_latency_ms": -5}).status_code, 400)
        self.assertEqual(self.c.put("/api/settings/rules", json={"severity_slow_api": "extreme"}).status_code, 400)
        self.assertEqual(self.c.put("/api/settings/rules", json={"api_latency_ms": 500}).status_code, 200)
        self.assertEqual(self.c.get("/api/settings/rules").get_json()["rules"]["api_latency_ms"], 500)
        self.assertEqual(self.c.post("/api/profiles", json={"name": "", "latency_ms": 5}).status_code, 400)
        self.assertEqual(self.c.post("/api/profiles", json={"name": "bad", "packet_loss_pct": 400}).status_code, 400)
        r = self.c.post("/api/profiles", json={"name": "Mine", "download_kbps": 800, "latency_ms": 100})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(self.c.delete("/api/profiles/standard").status_code, 404)  # built-ins protected
        self.assertEqual(self.c.delete(f"/api/profiles/{r.get_json()['id']}").status_code, 200)


class TargetSecurity(unittest.TestCase):
    def test_registered_target_accepted(self):
        self.assertEqual(validate_target_url("http://127.0.0.1:5055/anything", REG), "http://127.0.0.1:5055")

    def test_invalid_targets_rejected(self):
        bad = ["file:///etc/passwd", "ftp://127.0.0.1:5055", "javascript:alert(1)", "http://user:pw@127.0.0.1:5055",
               "http://169.254.169.254/latest/meta-data/", "http://metadata.google.internal/", "http://[fe80::1]/",
               "http://127.0.0.1:9999", "http://localhost:5055", "https://example.com", "http://10.0.0.5:5055", "", None, 123,
               "http://", "http://127.0.0.1:notaport", "x" * 5000]
        for u in bad:
            with self.assertRaises(TargetRejected, msg=str(u)[:40]):
                validate_target_url(u, REG)

    def test_metadata_blocked_even_if_registered(self):
        with self.assertRaises(TargetRejected):
            validate_target_url("http://169.254.169.254/", ["http://169.254.169.254"])

    def test_api_rejects_foreign_target_url(self):
        repo = temp_repo(); c = create_app(repo, RunManager(repo, check_reachable=False)).test_client()
        for u in ("http://169.254.169.254/", "https://example.com", "file:///etc/passwd"):
            r = c.post("/api/runs", json={"target_id": "demo-shop", "target_url": u, "profile_id": "standard", "workflow_id": "smoke_load"})
            self.assertEqual(r.status_code, 400, u); self.assertIn("rejected", r.get_json()["error"]["message"].lower())

    def test_in_browser_origin_filter(self):
        o = "http://127.0.0.1:5055"
        self.assertTrue(is_request_allowed("http://127.0.0.1:5055/static/a.js", o))
        self.assertTrue(is_request_allowed("data:image/png;base64,AAAA", o))
        self.assertFalse(is_request_allowed("http://169.254.169.254/latest", o))
        self.assertFalse(is_request_allowed("https://evil.example/x", o))
        self.assertFalse(is_request_allowed("http://127.0.0.1:6000/x", o))

    def test_concurrency_limit(self):
        repo = temp_repo(); mgr = RunManager(repo, check_reachable=False); c = create_app(repo, mgr).test_client()
        mgr.sem.acquire()   # simulate a running test
        r = c.post("/api/runs", json={"target_id": "demo-shop", "profile_id": "standard", "workflow_id": "smoke_load", "repetitions": 1})
        self.assertEqual(r.status_code, 429)
        mgr.sem.release()


if __name__ == "__main__":
    unittest.main()
