# Testing and evaluation report (generated from a real run)

Command: `python scripts/run_all_tests.py` · Environment: Python 3.12.3, Node v22.22.2, Linux 6.18.44-fc-v230, headless Chromium (Playwright) · Duration: 60 s
(Raw data: `docs/TESTING_REPORT.json`; plain `python -m unittest discover -s tests` reports 68 because the Node suite is run inside one wrapper test.)

| Measure | Count |
|---|---|
| Tests implemented | 75 |
| Tests executed | 75 |
| Passed | 75 |
| Failed | 0 |
| Not executed (skipped) | 0 |

## By layer
| Layer | Tests |
|---|---|
| API, validation and security | 14 |
| Rules, reports, comparison, persistence, export | 29 |
| Playwright integration (real Chromium) | 13 |
| Frontend UI tests (Chromium) | 11 |
| Frontend unit tests (Node node:test) | 8 |

## What is covered
Application startup · health endpoint · valid configuration · invalid target rejection (schemes, credentials, metadata/link-local, unregistered hosts/ports, malformed input) ·
successful browser execution with real measurements · timeout handling · failed-request detection · simulated packet loss labelled as simulated · enforcement + verification of bandwidth/latency ·
threshold classification and configurable severity · diagnostic report generation, hypothesis labelling and LLM fallback (stubbed) · persistence across restart · history filters · baseline comparison (incl. incompatible/ warning cases) ·
JSON and CSV export (incl. formula-injection guard) · in-browser origin blocking · cleanup of failed/cancelled browser sessions · concurrency limit · UI rendering of all 8 pages, XSS escaping, accessibility basics.

## Bugs found by the tests and fixed during development
1. `request.sizes()` blocked forever for responses that never fire `requestfinished` (HTTP 500) → engine now falls back to `Content-Length`.
2. Page metrics were lost when a later action in the same step timed out → metrics are now kept as soon as the page loads.
3. The skip-link (`#main`) was caught by the hash router and replaced the page with “Not found” → intercepted.
4. Config path bug (`ROOT` one level too high) found by UI smoke test → fixed.

## NOT tested / not executed (honest list)
* **Live LLM call** (`ANTHROPIC_API_KEY`): no key/network in the build environment; only the stubbed parsing/fallback path is tested.
* Physical Android devices, real mobile networks, OS-level traffic shaping (`tc`) — not implemented, so not tested.
* Browsers other than headless Chromium; operating systems other than Linux; Python versions other than 3.12; Node other than 22.
* Third-party / internet targets (blocked by design); the custom-target path was exercised against local test servers only.
* PDF export (not implemented). Load/stress testing and long-run soak testing. Screen-reader testing (only automated label/keyboard checks).
* Statistical robustness of results: runs use 1–10 repetitions; timing varies between runs, tests use wide margins accordingly.

## Individual tests
- `AppStartup.test_application_startup_and_health` — passed
- `AppStartup.test_catalogues` — passed
- `AppStartup.test_frontend_served` — passed
- `AppStartup.test_stats_empty_state` — passed
- `ConfigValidation.test_invalid_inputs_rejected` — passed
- `ConfigValidation.test_malformed_json_and_non_object` — passed
- `ConfigValidation.test_oversized_body` — passed
- `ConfigValidation.test_rule_and_profile_validation` — passed
- `TargetSecurity.test_api_rejects_foreign_target_url` — passed
- `TargetSecurity.test_concurrency_limit` — passed
- `TargetSecurity.test_in_browser_origin_filter` — passed
- `TargetSecurity.test_invalid_targets_rejected` — passed
- `TargetSecurity.test_metadata_blocked_even_if_registered` — passed
- `TargetSecurity.test_registered_target_accepted` — passed
- `Classification.test_below_ratio_not_flagged` — passed
- `Classification.test_clean_run_has_no_findings_and_passes` — passed
- `Classification.test_core_step_failing_always_is_critical` — passed
- `Classification.test_extreme_latency_escalates_to_high` — passed
- `Classification.test_failed_request_js_error_and_page_rules` — passed
- `Classification.test_flaky_step_is_medium` — passed
- `Classification.test_noncore_step_failing_always_is_high_not_critical` — passed
- `Classification.test_severity_rules_are_configurable` — passed
- `Classification.test_slow_api_threshold_message_and_evidence` — passed
- `Comparison.test_bad_compare_requests` — passed
- `Comparison.test_compare_differences_new_and_resolved` — passed
- `Comparison.test_incompatible_workflows_refused` — passed
- `Comparison.test_percent_change_math` — passed
- `Comparison.test_regressions_detected_when_reversed` — passed
- `Comparison.test_warning_when_conditions_differ` — passed
- `PersistenceAndExport.test_csv_export_all_parts_and_formula_injection` — passed
- `PersistenceAndExport.test_history_filters` — passed
- `PersistenceAndExport.test_interrupted_runs_marked_failed_on_startup` — passed
- `PersistenceAndExport.test_json_export` — passed
- `PersistenceAndExport.test_results_survive_restart` — passed
- `Reports.test_hypotheses_are_labelled_and_observations_confirmed` — passed
- `Reports.test_llm_failure_falls_back_to_deterministic` — passed
- `Reports.test_llm_garbage_output_handled` — passed
- `Reports.test_llm_output_is_labelled_and_cannot_change_severity` — passed
- `Reports.test_llm_requires_key_via_api` — passed
- `Reports.test_no_secret_in_prompt` — passed
- `Reports.test_report_persisted_and_complete` — passed
- `Reports.test_report_states_what_is_not_measured` — passed
- `Reports.test_server_vs_network_split_uses_server_timing` — passed
- `BrowserIntegration.test_browser_is_cleaned_up_after_unexpected_engine_error` — passed
- `BrowserIntegration.test_cancellation_stops_run_and_cleans_up` — passed
- `BrowserIntegration.test_constrained_network_enforced_then_optimisation_compared` — passed
- `BrowserIntegration.test_cross_origin_requests_from_page_are_blocked` — passed
- `BrowserIntegration.test_deliberate_demo_faults_are_detected` — passed
- `BrowserIntegration.test_failed_request_detection_via_api_workflow` — passed
- `BrowserIntegration.test_packet_loss_is_simulated_and_labelled` — passed
- `BrowserIntegration.test_second_run_rejected_while_one_is_active` — passed
- `BrowserIntegration.test_start_refuses_unreachable_target_up_front` — passed
- `BrowserIntegration.test_successful_execution_records_real_measurements` — passed
- `BrowserIntegration.test_timeout_is_enforced_and_recorded` — passed
- `BrowserIntegration.test_unenforceable_constraint_aborts_instead_of_running_unconstrained` — passed
- `BrowserIntegration.test_unreachable_target_yields_critical_finding` — passed
- `FrontendUnit.test_node_unit_tests` — passed
- `UiPages.test_compare_page_shows_warning_resolved_and_math` — passed
- `UiPages.test_dashboard_empty_state` — passed
- `UiPages.test_dashboard_numbers_come_from_stored_runs` — passed
- `UiPages.test_every_page_renders_without_errors` — passed
- `UiPages.test_history_filter_and_select_two_to_compare` — passed
- `UiPages.test_incompatible_compare_shows_message` — passed
- `UiPages.test_keyboard_and_labels_basic_accessibility` — passed
- `UiPages.test_labels_are_escaped_no_xss` — passed
- `UiPages.test_new_test_form_validates_and_unavailable_actions_labelled` — passed
- `UiPages.test_report_shows_evidence_hypotheses_and_disabled_llm` — passed
- `UiPages.test_settings_rules_roundtrip` — passed
