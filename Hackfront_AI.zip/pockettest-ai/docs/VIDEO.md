# Demo video — PocketTest_AI_Demo.mp4

**What it is:** a real, unedited screen recording (1280×720, 157 s, H.264) of the running application, produced by
`scripts/record_demo_video.py`, which drives the actual UI with Playwright. Nothing is mocked: the runs shown were executed live during the recording
(1 repetition each, to keep waits short) against the local demo app, and the numbers in captions are read from the API at that moment.

**Honest notes**
* Captions only — **no spoken narration** (no text-to-speech engine in the build environment). A voice-over script is below.
* 157 s is slightly over the 150 s guideline in the brief; trim the two execution waits if the hackathon enforces a hard cap.
* A small cyan dot is an injected cursor overlay so viewers can follow clicks; it is not part of the product.
* Values come from a single repetition per run, so findings read "1 of 1". The scenario results in `docs/demo-scenario-results.json` use 3 repetitions.

## Caption timeline (as recorded)
| Time | Caption |
|---|---|
| 0:00 | PocketTest AI finds how a web app behaves under constrained conditions — before users do. |
| 0:05 | Dashboard: every figure is computed from stored runs. No runs yet, so these are empty states. |
| 0:10 | New Test: pick the local demo app, the Standard profile and the shop-checkout workflow. |
| 0:15 | Playwright drives a real Chromium browser through the workflow while we monitor progress. |
| 0:28 | Measured, not invented: page load 20 ms median, API latency 303 ms, 1 failed request(s), 1 JS error(s). |
| 0:34 | Browser timings and server-reported time are recorded as separate measurements. |
| 0:38 | Result: FAILED — the demo app has deliberate faults (a timeout, an HTTP 500, a JS exception). |
| 0:45 | Now the Constrained profile: 1000 kbps, 150 ms latency, 4x CPU slowdown — emulated in Chromium via DevTools. |
| 0:51 | Same app, same workflow, constrained conditions. |
| 1:13 | Home page load: 53 ms before → 6501 ms under constraints. Those are measured values. |
| 1:19 | Enforcement is reported honestly: applied via DevTools emulation and verified against observed throughput. |
| 1:24 | Findings come from transparent rules: a slow API and a slow page now appear that standard conditions hid. |
| 1:30 | Diagnostic report: severity is rule-based. An LLM never sets it, and none is needed to use the app. |
| 1:36 | Observations are confirmed measurements. Possible causes are labelled hypothesis or estimated — never stated as fact. |
| 1:42 | Each finding lists evidence, reproduction steps, confidence and what to investigate next. |
| 1:48 | Apply the sample optimization to the demo app, then re-run under identical conditions. |
| 2:01 | After the fix, same constrained profile: home load 1062 ms, 0 issues, verdict PASSED. |
| 2:08 | Run comparison: same workflow and conditions, so the result is compatible — no warning. |
| 2:13 | Absolute and percent differences are shown; percent only where the baseline is non-zero. |
| 2:18 | Resolved failures and any new failures are listed explicitly. |
| 2:24 | Configure → run in a real browser → measure → classify → explain → compare. All reproducible, all stored. |
| 2:29 | Honest scope: Chromium emulation on a laptop — not a physical-device benchmark. Packet loss is simulated and labelled. |

## Voice-over script (≈150 words/min pace; read over the same footage)
1. *(0:00)* "Apps are usually tested on fast laptops and fast networks. PocketTest AI lets developers see what happens when conditions are tougher — before users find out."
2. *(0:05)* "This dashboard is empty on purpose: every figure comes from stored test runs."
3. *(0:10)* "We pick the local demo shop, the Standard profile and the checkout workflow, and start. A real Chromium browser is driven by Playwright."
4. *(0:28)* "These are measured timings: page load, API latency, failed requests and JavaScript errors. Browser timing and server-reported time are kept separate."
5. *(0:45)* "Now the Constrained profile — limited bandwidth, extra latency, slower CPU, applied through Chromium's DevTools and verified against observed throughput."
6. *(1:13)* "The home page takes about six and a half seconds instead of tens of milliseconds, and new issues appear that the standard run hid."
7. *(1:30)* "The diagnostic report separates what was confirmed from what is only a possible cause, and severity comes from documented rules, never from an LLM."
8. *(1:48)* "We apply a sample optimization to the demo app and re-run under identical conditions."
9. *(2:08)* "The comparison shows the differences, resolved failures, and no new ones."
10. *(2:24)* "Configure, run, measure, classify, explain, compare. Scope: browser emulation on a laptop — not a physical-device benchmark."

## Recording plan (to re-record)
1. Start the demo app (`python demo-app/server.py`) and the backend on an **empty** DB (`POCKETTEST_DB=/tmp/video.sqlite3 python backend/run_server.py`).
2. `python scripts/record_demo_video.py` (≈3 min; writes `video/raw/*.webm`).
3. `ffmpeg -i video/raw/*.webm -c:v libx264 -crf 24 -pix_fmt yuv420p -movflags +faststart video/PocketTest_AI_Demo.mp4`
4. Optional voice-over: record the script above and mux with `ffmpeg -i video.mp4 -i vo.wav -c:v copy -c:a aac -shortest out.mp4`.
