# PocketTest AI — Architecture

## 1. What it is
A local, browser-based application-testing platform: configure a test → execute a Playwright/Chromium workflow under emulated
conditions → collect measurements → classify issues with transparent rules → generate an evidence-based diagnostic report →
persist and compare runs.

It deliberately measures **browser behaviour under emulated constraints on the developer's machine**. It is *not* a physical-device
benchmark (see `LIMITATIONS.md`).

## 2. Components

```
 Browser UI (frontend/, ES modules, no build step)
        │  REST/JSON
 Flask API (backend/app/server.py) ── RunManager (runner.py) ── 1 worker thread per run, concurrency-limited
        │                                   │
        │                                   ├─ engine.py  : Playwright + Chromium, CDP emulation, event capture
        │                                   ├─ classifier.py : deterministic rules → findings + run summary
        │                                   ├─ analysis.py   : deterministic report (+ optional LLM add-on)
        │                                   └─ compare.py / exports.py
        └─ db.py (Repo, SQLite; all SQL isolated here → swap for PostgreSQL later)

 demo-app/server.py  : "PocketShop" with deliberate, reproducible faults + an optimisation switch (isolated from product code)
```

| Layer | Choice | Why |
|---|---|---|
| Frontend | Vanilla ES modules, SVG charts written in-repo | No registry access in the build environment; zero runtime deps; `node --test` unit tests |
| Backend | Python 3.12, **Flask** | FastAPI/pydantic were not installable offline; input validation is hand-written in `runner.py` |
| Automation | Playwright (Python) + Chromium | As specified |
| Storage | SQLite (`backend/schema.sql`) | As specified; repository layer in `db.py` |
| Tests | `unittest` (also runs under `pytest`), Node `node:test`, Playwright | pytest not installable offline |

> **Deviation from the brief:** the preferred stack was React/TypeScript/Vite/Tailwind + FastAPI/pytest. Those packages were not
> available in the build sandbox (no network), and code that cannot be executed cannot be verified. The architecture keeps the same
> seams (REST contract, repository layer, engine/classifier/analysis split), so a React or FastAPI port is mechanical.

## 3. Data model (SQLite)
`runs` (config snapshot: profile, rules, environment/enforcement, summary, verdict) · `step_results` · `requests` ·
`page_metrics` · `js_errors` · `findings` · `reports` · `settings` (custom profiles, rules). See `backend/schema.sql`.
Each run stores the **profile and rules it used**, so old reports stay interpretable after settings change.

## 4. Test execution (engine.py)
1. Launch Chromium (headless). One fresh browser context per repetition (cold cache; request interception bypasses HTTP cache).
2. Install a route handler: (a) **origin guard** – only the registered target origin (plus `data:`/`blob:`) may be requested;
   everything else is aborted and counted; (b) optional **fault injection** for simulated packet loss.
3. Apply constraints with CDP and record an **enforcement record per setting** (see §6).
4. Execute declarative workflow steps (`navigate`, `form`, `click_wait`, `api`) with per-step timeouts.
5. After each step: collect requests (browser timing, size, `X-Server-Time-Ms`), page metrics (Navigation/Paint/LCP timing), JS errors.
6. `finally`: close contexts, browser and Playwright; decrement the open-browser counter (tested).

### Metrics and sources
| Metric | Source | Notes |
|---|---|---|
| Navigation, DOMContentLoaded, load | Navigation Timing API | per page, per repetition |
| FCP, LCP | Paint Timing / PerformanceObserver (buffered) | `n/a` if the page paints nothing |
| Request latency, status | Playwright `request.timing` / `response` | label: browser |
| Transfer size | Playwright `request.sizes()` / Resource Timing | |
| Server time | `X-Server-Time-Ms` response header | **only** targets that send it (demo app) |
| JS errors | `pageerror`, console errors | resource-load console errors excluded (already request failures) |
| **Not measured** | RAM, battery, thermals, real-device crashes, carrier behaviour | never claimed |

## 5. Issue classification (classifier.py) — never LLM-assigned
| Rule | Trigger | Severity |
|---|---|---|
| STEP_FAILED | core step fails in 100 % of attempts | **critical** |
| | other step fails in 100 %, or ≥ `failure_ratio_high` of attempts | **high** |
| | fewer failing attempts (flaky) | medium |
| REQUEST_FAILED | per METHOD+path, HTTP ≥ 400 / network failure; share ≥ `failure_ratio_high` | high, else medium |
| SLOW_API | browser latency > `api_latency_ms` in ≥ `api_latency_min_exceed_ratio` of attempts | `severity_slow_api` (medium); median > `api_latency_high_multiplier`× threshold → high |
| SLOW_PAGE_LOAD | median load > `page_load_ms` | `severity_slow_page` (medium) |
| JS_ERROR | uncaught exception / console error | `severity_js_error` (medium) |
| LARGE_TRANSFER | median bytes > `page_transfer_kb` | `severity_large_transfer` (low) |
| Regression | comparison only: ≥ `regression_pct` and ≥ `regression_min_abs_ms` worse | medium |

All thresholds are editable in **Settings** (`PUT /api/settings/rules`) and snapshotted per run. Run **verdict** = `failed` if a core step
failed or a finding has a severity in `fail_on_severity` (default critical/high).

## 6. Honesty about network conditions
| Setting | Mechanism | Status label |
|---|---|---|
| Download/upload bandwidth, latency | CDP `Network.emulateNetworkConditions` (browser-level) | `applied` + post-run **verification** against observed throughput/latency |
| CPU slowdown | CDP `Emulation.setCPUThrottlingRate` | `applied` (relative to host CPU) |
| Packet loss | seeded random abort of non-document requests | **`simulated`** — explicitly *not* TCP-level loss |
| Not requested | — | `not_requested`; the run is an unmodified browser session and says so |
If a requested constraint cannot be applied, the **run fails** (tested) instead of running unconstrained.
OS-level shaping (`tc netem`) was not used: it needs root and a kernel module, and `tc` was not available in the build environment.

## 7. Diagnostic reports (analysis.py)
Deterministic generator always works. Per finding: title, severity, operation, **observation (confirmed)**, evidence (each line tagged
measured/simulated), reproduction steps, **possible causes** (each tagged measured / estimated / hypothesis + confidence), recommended
investigation, confidence note. Example of evidence-based reasoning: if server-reported time is 451 ms of a 1489 ms request, the report says
the remaining ~1.0 s happened *outside server processing* and estimates transfer time from payload size ÷ configured bandwidth, labelled
*estimated* — it never says "the database is slow".
Optional LLM (`ANTHROPIC_API_KEY`, server-side only): adds explanations and extra hypotheses, labelled "AI-generated hypothesis – not
confirmed". It cannot alter severity/evidence/verdict; on any error the deterministic report remains. **The live LLM call path has not been
executed** (no network/key in the build environment); parsing, labelling and fallback are unit-tested with a stub.

## 8. Security (see also LIMITATIONS.md)
* Targets are registered (`POCKETTEST_ALLOWED_TARGETS` adds more); `target_url`, if supplied, must match a registered origin exactly.
* Rejected: non-http(s) schemes, credentials in URL, metadata/link-local/multicast addresses (even if registered), unregistered
  localhost ports, malformed/oversized input.
* In-browser origin guard blocks page-initiated requests to other hosts (SSRF from the page under test).
* No shell commands are built from input; secrets only via environment variables; API key never reaches the frontend.
* Concurrency limit (default 1 run → HTTP 429), body size limit 256 KB, repetitions 1–10, run-level wall-clock cap, per-step timeouts.
* CSV export neutralises spreadsheet-formula injection; UI escapes all dynamic text (XSS-tested).
* The server binds to 127.0.0.1 and has **no authentication** — do not expose it.
