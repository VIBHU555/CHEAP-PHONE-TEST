# Known limitations and future work

## Limitations (honest scope)
1. **Not a physical-device benchmark.** Tests run in headless desktop Chromium on the developer's machine. Bandwidth/latency/CPU
   "profiles" are example configurations applied by DevTools emulation; they are not measurements of any particular Indian smartphone
   or carrier. RAM, battery, thermal throttling, GPU, OS memory pressure and native-app crashes are **not measured**.
2. **Emulation, not OS traffic control.** Network shaping is Chromium-level (CDP). It does not affect other processes and does not
   model TCP dynamics, radio state or handovers. `tc netem` / proxy-based shaping is future work (needs root; `tc` was unavailable here).
3. **Packet loss is simulated** by aborting a seeded share of non-document requests. Real loss would be retransmitted by TCP.
4. **CPU slowdown** scales the renderer relative to the host CPU; "4x" on a fast laptop is not "a 4x slower phone".
5. **Server-side timing** is only available for targets that send `X-Server-Time-Ms` (the demo app). Otherwise reports say so.
6. **Cold loads only**: request interception bypasses the HTTP cache; warm-cache and service-worker behaviour are not tested.
7. **Workflows are predefined** (3 shipped; selectors are demo-specific except `smoke_load`). No recorder / custom-script UI yet.
8. **Sample sizes are small** (1–10 repetitions). Medians/p95 over few samples are indicative, not statistically rigorous; no confidence intervals.
9. **Single-user, local-only**: no authentication, binds to 127.0.0.1, one concurrent run. Do not expose it to a network.
10. **LLM explanations**: implemented but the live API call was **not executed** in the build environment (no key/network). Parsing, labelling
    and fallback are unit-tested with a stub. Treat as untested against the real API until you try it.
11. **PDF export** not implemented (optional in the brief); the UI shows it as unavailable.
12. **Stack deviation**: Flask + vanilla ES modules + unittest instead of FastAPI/React/TypeScript/Vite/Tailwind/pytest (packages unavailable offline).
13. Custom (non-demo) targets are supported only through `POCKETTEST_ALLOWED_TARGETS` and the generic `smoke_load` workflow; this path was
    exercised only against a local test server in the automated tests, not against third-party sites (by design).
14. The demo video has **captions but no spoken narration** (no TTS available when it was produced); a narration script is provided.

## Future improvements
* React/TypeScript frontend and FastAPI/pydantic backend port; PostgreSQL via the existing repository seam.
* Proxy/`tc`-based shaping with verification; real packet-loss modelling; Android emulator/device-farm runners (adb, Perfetto, memory/CPU traces).
* Workflow recorder and user-defined steps; Lighthouse/Web-Vitals (INP, CLS, TBT) collection; HAR export.
* Statistical comparison (Mann–Whitney, bootstrap CIs) and automatic baseline selection; CI integration (`pockettest run --fail-on high`).
* PDF report; authentication and multi-user storage; scheduled runs.
