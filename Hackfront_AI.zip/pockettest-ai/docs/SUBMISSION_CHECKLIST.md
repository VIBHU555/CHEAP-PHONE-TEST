# Before you submit — remaining tasks

**Must do (cannot be done by the build):**
- [ ] Replace team placeholders: `[TEAM NAME] · [MEMBER NAMES] · [CONTACT]` in slides 1 and 12 (rebuild with `NODE_PATH=$(npm root -g) node presentation/build_deck.js`, or edit in PowerPoint), and in `LICENSE`.
- [ ] Check the hackathon's actual rules for slide count, video length (current video: 157 s, captions only) and file size.
- [ ] Record a voice-over if wanted (script in `docs/VIDEO.md`) or keep captions.
- [ ] Run the app once on **your** machine from a clean checkout (`README.md` → Install → Run → Tests) — it was verified in a Linux sandbox only.
- [ ] If you want LLM explanations: set `ANTHROPIC_API_KEY`, click *Add LLM explanations*, and confirm it works — this path has **not** been run live.

**Recommended:**
- [ ] Rehearse the 10-step demo (`scripts/run_demo_scenario.py` shows what to expect; timings vary by machine).
- [ ] Re-capture screenshots/video on your machine if you want your own numbers (`scripts/capture_screenshots.py`, `scripts/record_demo_video.py`); the deck reads numbers from `docs/demo-scenario-results.json`, so re-run the scenario and rebuild the deck to stay consistent.
- [ ] Decide whether to mention the stack deviation (Flask/vanilla JS instead of FastAPI/React) — it is documented in README/ARCHITECTURE/LIMITATIONS.

**Verified in the build environment:** 75/75 automated tests passed (`docs/TESTING_REPORT.md`); PPTX schema-validated and rendered; video is a real recording of the running app.
