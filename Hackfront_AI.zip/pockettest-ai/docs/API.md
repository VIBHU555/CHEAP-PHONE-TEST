# PocketTest AI — REST API (JSON)

Base URL `http://127.0.0.1:8000/api`. Errors: `{"error":{"code","message"}}` with 400 validation, 404 not found, 409 conflict/incompatible, 413 too large, 429 busy.

| Method & path | Purpose |
|---|---|
| `GET /health` | status, version, DB ok, active runs, open browsers, `llm_configured` |
| `GET /targets` · `GET /workflows` · `GET /profiles` | catalogues (targets include demo-app mode) |
| `POST /profiles` · `DELETE /profiles/<id>` | custom profile `{name, download_kbps?, upload_kbps?, latency_ms, packet_loss_pct, cpu_slowdown, step_timeout_ms}`; built-ins protected |
| `GET/PUT /settings/rules` · `POST /settings/rules/reset` | severity rules |
| `POST /runs` → `202 {id}` | `{target_id, profile_id, workflow_id, repetitions(1-10), label?, target_url?}`; 429 if a run is active; 400 for invalid/unregistered targets |
| `GET /runs?status=&verdict=&profile_id=&from=&to=&limit=` | history (newest first) |
| `GET /runs/<id>` | run + steps + requests + page_metrics + js_errors + findings (poll for progress: `run.progress`) |
| `POST /runs/<id>/cancel` · `DELETE /runs/<id>` | cooperative cancel (after current step) · delete finished run |
| `GET /runs/<id>/report` | diagnostic report |
| `POST /runs/<id>/report/regenerate` `{use_llm}` | regenerate; `use_llm:true` needs server `ANTHROPIC_API_KEY` |
| `GET /runs/<id>/export?format=json` · `?format=csv&part=findings\|requests\|steps\|page_metrics\|js_errors` | download |
| `GET /compare?a=<baseline>&b=<new>` | 409 if workflow/target differ; `warnings` if conditions differ |
| `GET /stats` | dashboard aggregates computed from stored runs |
| `GET/POST /demo/mode` `{optimized: bool}` | toggle the demo app's sample optimisation (demo target only; refused while a run is active) |
