#!/usr/bin/env bash
# Start/stop the demo app (port 5055) and the PocketTest backend (port 8000) using pid files.
# Usage: scripts/dev_servers.sh start|stop|status   (optional env: POCKETTEST_DB=/path/to.sqlite3)
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; RUN="${TMPDIR:-/tmp}/pockettest-pids"; mkdir -p "$RUN"
stop_one(){ [ -f "$RUN/$1.pid" ] && kill "$(cat "$RUN/$1.pid")" 2>/dev/null; rm -f "$RUN/$1.pid"; }
case "$1" in
  start)
    (cd "$ROOT/demo-app" && setsid nohup python3 server.py >"$RUN/demo.log" 2>&1 </dev/null & echo $! >"$RUN/demo.pid")
    (cd "$ROOT/backend" && setsid nohup python3 run_server.py >"$RUN/backend.log" 2>&1 </dev/null & echo $! >"$RUN/backend.pid")
    sleep 2; echo "demo-app  : http://127.0.0.1:5055"; echo "pockettest: http://127.0.0.1:8000" ;;
  stop) stop_one backend; stop_one demo; echo stopped ;;
  status) curl -s -m 2 localhost:5055/api/health || echo "demo down"; echo; curl -s -m 2 localhost:8000/api/health || echo "backend down"; echo ;;
  *) echo "usage: $0 start|stop|status"; exit 1 ;;
esac
