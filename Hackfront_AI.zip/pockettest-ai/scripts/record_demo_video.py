#!/usr/bin/env python3
"""Record the PocketTest AI demo by driving the REAL UI with Playwright (video of the actual running app).

Requirements: backend on :8000 with an EMPTY database and the demo app on :5055 in its default (unoptimized) mode.
Captions are injected into the page and recorded with it; numbers quoted in captions are read from the API at that moment.
Output: video/raw/*.webm  (then convert with ffmpeg, see docs/VIDEO.md)
"""
import json, os, sys, time, urllib.request
from playwright.sync_api import sync_playwright

BASE = os.environ.get("POCKETTEST_URL", "http://127.0.0.1:8000")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "video", "raw")
os.makedirs(OUT, exist_ok=True)
T0 = time.time()
LOG = []

CAPTION_JS = """
(() => {
  if (document.getElementById('pt-cap')) return;
  const s = document.createElement('style');
  s.textContent = `#pt-cap{pointer-events:none;position:fixed;left:50%;bottom:22px;transform:translateX(-50%);max-width:1040px;width:calc(100% - 80px);z-index:99999;
    background:rgba(4,10,20,.94);color:#fff;border:1px solid #38bdf8;border-radius:12px;padding:12px 20px;font:600 21px/1.35 Inter,system-ui,sans-serif;
    text-align:center;box-shadow:0 8px 30px rgba(0,0,0,.5);opacity:0;transition:opacity .25s}#pt-cap.on{opacity:1}
    #pt-cur{position:fixed;width:18px;height:18px;border-radius:50%;background:rgba(56,189,248,.55);border:2px solid #fff;z-index:99998;pointer-events:none;left:-40px;top:-40px;transition:left .02s,top .02s}`;
  document.head.appendChild(s); const pad = document.createElement('style'); pad.textContent = 'main{padding-bottom:150px !important}'; document.head.appendChild(pad);
  const c = document.createElement('div'); c.id = 'pt-cap'; c.setAttribute('aria-hidden', 'true'); document.body.appendChild(c);
  const d = document.createElement('div'); d.id = 'pt-cur'; document.body.appendChild(d);
  document.addEventListener('mousemove', (e) => { d.style.left = e.clientX - 9 + 'px'; d.style.top = e.clientY - 9 + 'px'; });
})();
"""


def api(path):
    with urllib.request.urlopen(BASE + "/api" + path, timeout=30) as r:
        return json.loads(r.read())


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1280, "height": 720}, record_video_dir=OUT, record_video_size={"width": 1280, "height": 720})
        page = ctx.new_page()
        page.goto(BASE + "/#/"); page.wait_for_selector("main h1"); page.evaluate(CAPTION_JS)

        def say(text, hold=None):
            page.evaluate("t => { const c = document.getElementById('pt-cap'); c.textContent = t; c.classList.add('on'); }", text)
            LOG.append((round(time.time() - T0, 1), text))
            time.sleep(hold if hold is not None else max(3.0, len(text) * 0.05))

        def clear():
            page.evaluate("document.getElementById('pt-cap').classList.remove('on')")

        def click(sel):
            page.locator(sel).first.evaluate("e => e.scrollIntoView({block: 'center', behavior: 'instant'})"); time.sleep(0.3)
            box = page.locator(sel).first.bounding_box()
            page.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2, steps=18); time.sleep(0.35)
            page.locator(sel).first.click(); time.sleep(0.4)

        def scroll(px, hold=1.0):
            page.evaluate("y => window.scrollBy({top: y, behavior: 'smooth'})", px); time.sleep(hold)

        def wait_results(timeout=150):
            page.wait_for_url(lambda u: "/runs/" in u and "/execution" not in u, timeout=timeout * 1000); page.wait_for_selector("text=Test Results"); time.sleep(0.6)

        # ---------------------------------------------------------------- 1. intro + dashboard (empty, honest)
        say("PocketTest AI finds how a web app behaves under constrained conditions — before users do.", 4.5)
        say("Dashboard: every figure is computed from stored runs. No runs yet, so these are empty states.", 4.0)

        # ---------------------------------------------------------------- 2. configure + run standard
        click("#nav a[data-r=new]"); page.wait_for_selector("#f"); page.evaluate("window.scrollTo(0,0)")
        say("New Test: pick the local demo app, the Standard profile and the shop-checkout workflow.", 3.0)
        page.fill("#r", "1"); page.fill("#l", "baseline - standard network"); time.sleep(0.8)
        click("#go")
        say("Playwright drives a real Chromium browser through the workflow while we monitor progress.", 3.5)
        wait_results()
        std = api("/runs")[0]; s = std["summary"]
        say(f"Measured, not invented: page load {s['median_load_ms']:.0f} ms median, API latency {s['median_api_ms']:.0f} ms, {s['failed_requests']} failed request(s), {s['js_errors']} JS error(s).", 5.0)
        scroll(520, 0.6); say("Browser timings and server-reported time are recorded as separate measurements.", 3.5); scroll(700, 0.8)
        say(f"Result: {std['verdict'].upper()} — the demo app has deliberate faults (a timeout, an HTTP 500, a JS exception).", 4.5)

        # ---------------------------------------------------------------- 3. constrained run
        page.evaluate("window.scrollTo(0,0)"); click("#nav a[data-r=new]"); page.wait_for_selector("#f")
        page.select_option("#p", "constrained"); page.fill("#r", "1"); page.fill("#l", "constrained network - before fix"); time.sleep(0.6)
        say("Now the Constrained profile: 1000 kbps, 150 ms latency, 4x CPU slowdown — emulated in Chromium via DevTools.", 4.5)
        click("#go")
        say("Same app, same workflow, constrained conditions.", 3.0)
        wait_results()
        con = api("/runs")[0]; cs = con["summary"]
        say(f"Home page load: {s['by_page']['/']['load_ms']:.0f} ms before → {cs['by_page']['/']['load_ms']:.0f} ms under constraints. Those are measured values.", 5.0)
        page.evaluate("document.querySelectorAll('main .card')[1].scrollIntoView({behavior:'smooth'})"); time.sleep(1.0)
        say("Enforcement is reported honestly: applied via DevTools emulation and verified against observed throughput.", 4.5)
        page.evaluate("document.querySelectorAll('main .card')[2].scrollIntoView({behavior:'smooth'})"); time.sleep(0.8)
        say("Findings come from transparent rules: a slow API and a slow page now appear that standard conditions hid.", 4.5)

        # ---------------------------------------------------------------- 4. diagnostic report
        page.evaluate("window.scrollTo(0,0)"); click("a.btn:has-text('Open AI diagnostic report')"); page.wait_for_selector("text=AI Diagnostic Report")
        say("Diagnostic report: severity is rule-based. An LLM never sets it, and none is needed to use the app.", 4.5)
        page.evaluate("document.querySelectorAll('details.f')[2].scrollIntoView({behavior:'smooth', block:'start'})"); time.sleep(1.2)
        say("Observations are confirmed measurements. Possible causes are labelled hypothesis or estimated — never stated as fact.", 5.5)
        scroll(260, 1.0)
        say("Each finding lists evidence, reproduction steps, confidence and what to investigate next.", 4.0)

        # ---------------------------------------------------------------- 5. optimise + re-run
        page.evaluate("window.scrollTo(0,0)"); click("#opt"); page.wait_for_selector("#f", timeout=15000)
        say("Apply the sample optimization to the demo app, then re-run under identical conditions.", 3.5)
        page.fill("#r", "1"); click("#go")
        wait_results()
        aft = api("/runs")[0]; af = aft["summary"]
        say(f"After the fix, same constrained profile: home load {af['by_page']['/']['load_ms']:.0f} ms, {sum(af['issue_counts'].values())} issues, verdict {aft['verdict'].upper()}.", 5.0)

        # ---------------------------------------------------------------- 6. compare
        page.select_option("#cmp", con["id"]); click("#cmpgo"); page.wait_for_selector("text=Resolved failures")
        page.evaluate("window.scrollTo(0,0)")
        say("Run comparison: same workflow and conditions, so the result is compatible — no warning.", 4.0)
        scroll(430, 0.8); say("Absolute and percent differences are shown; percent only where the baseline is non-zero.", 4.0)
        page.evaluate("[...document.querySelectorAll('main h2')].find(h=>h.textContent.startsWith('New failures')).scrollIntoView({behavior:'smooth'})"); time.sleep(1.0)
        say("Resolved failures and any new failures are listed explicitly.", 3.5)

        # ---------------------------------------------------------------- 7. wrap-up
        page.evaluate("window.scrollTo(0,0)"); click("#nav a[data-r=dashboard]"); page.wait_for_selector("text=Tests executed"); time.sleep(0.8)
        say("Configure → run in a real browser → measure → classify → explain → compare. All reproducible, all stored.", 5.0)
        say("Honest scope: Chromium emulation on a laptop — not a physical-device benchmark. Packet loss is simulated and labelled.", 5.5)
        clear(); time.sleep(0.8)
        path = page.video.path()
        ctx.close(); browser.close()
    print("video:", path, "duration ~", round(time.time() - T0), "s")
    json.dump(LOG, open(os.path.join(OUT, "caption_timeline.json"), "w"), indent=1)


if __name__ == "__main__":
    sys.exit(main())
