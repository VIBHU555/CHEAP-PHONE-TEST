#!/usr/bin/env python3
"""Run the documented demo scenario against a running PocketTest backend (default http://127.0.0.1:8000).

  1. standard profile, demo app UNOPTIMIZED   (baseline)
  2. constrained profile, UNOPTIMIZED         (observe differences)
  3. apply the sample optimisation to the demo app
  4. constrained profile, OPTIMIZED           (re-run under identical conditions)
  5. standard profile, OPTIMIZED
Prints a summary and writes docs/demo-scenario-results.json. All numbers come from real runs.
"""
import json, os, sys, time, urllib.error, urllib.request

BASE = os.environ.get("POCKETTEST_URL", "http://127.0.0.1:8000")
OUT = os.path.join(os.path.dirname(__file__), "..", "docs", "demo-scenario-results.json")


def call(path, body=None, method=None):
    req = urllib.request.Request(BASE + path, data=None if body is None else json.dumps(body).encode(), method=method or ("POST" if body is not None else "GET"),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise SystemExit(f"API error {e.code}: {e.read().decode()[:300]}")


def run(profile, label, reps=3):
    rid = call("/api/runs", {"target_id": "demo-shop", "profile_id": profile, "workflow_id": "shop_checkout", "repetitions": reps, "label": label})["id"]
    t0 = time.time()
    while True:
        r = call(f"/api/runs/{rid}")["run"]
        if r["status"] not in ("queued", "running"):
            break
        time.sleep(1)
    print(f"  {label}: {r['status']}/{r['verdict']} in {time.time() - t0:.0f}s  issues={r['summary']['issue_counts'] if r['summary'] else r['error']}")
    return rid, r


def main():
    results = {}
    call("/api/demo/mode", {"optimized": False})
    print("1/5 baseline"); a, ra = run("standard", "1 · Baseline — standard network (before fix)")
    print("2/5 constrained"); b, rb = run("constrained", "2 · Constrained network (before fix)")
    print("3/5 applying sample optimisation to the demo app"); call("/api/demo/mode", {"optimized": True})
    print("4/5 constrained after fix"); c, rc = run("constrained", "3 · Constrained network (after fix)")
    print("5/5 standard after fix"); d, rd = run("standard", "4 · Standard network (after fix)")
    cmp_cond = call(f"/api/compare?a={a}&b={b}")
    cmp_fix = call(f"/api/compare?a={b}&b={c}")
    results = {"run_ids": {"standard_before": a, "constrained_before": b, "constrained_after": c, "standard_after": d},
               "summaries": {k: v["summary"] for k, v in zip(["standard_before", "constrained_before", "constrained_after", "standard_after"], [ra, rb, rc, rd])},
               "compare_conditions_standard_vs_constrained": {k: cmp_cond[k] for k in ("warnings", "pages", "endpoints", "new_failures", "resolved_failures")},
               "compare_fix_constrained_before_vs_after": {k: cmp_fix[k] for k in ("warnings", "notes", "pages", "endpoints", "totals", "new_failures", "resolved_failures", "regressions")}}
    with open(OUT, "w") as f:
        json.dump(results, f, indent=2)
    print("wrote", os.path.abspath(OUT))
    call("/api/demo/mode", {"optimized": False})   # leave demo app in its default state


if __name__ == "__main__":
    sys.exit(main())
