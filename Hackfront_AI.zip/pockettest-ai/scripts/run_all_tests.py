#!/usr/bin/env python3
"""Run the whole suite (unittest + Node) and write docs/TESTING_REPORT.json with REAL counts (no hand-entered numbers)."""
import json, os, platform, re, subprocess, sys, time, unittest
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "tests"))


class Result(unittest.TextTestResult):
    def __init__(self, *a, **k):
        super().__init__(*a, **k); self.rows = []
    def addSuccess(self, t): super().addSuccess(t); self.rows.append((t.id(), "passed", ""))
    def addFailure(self, t, e): super().addFailure(t, e); self.rows.append((t.id(), "failed", self._exc_info_to_string(e, t)[-600:]))
    def addError(self, t, e): super().addError(t, e); self.rows.append((t.id(), "error", self._exc_info_to_string(e, t)[-600:]))
    def addSkip(self, t, r): super().addSkip(t, r); self.rows.append((t.id(), "skipped", r))


def main():
    t0 = time.time()
    suite = unittest.defaultTestLoader.discover(os.path.join(ROOT, "tests"))
    res = unittest.TextTestRunner(verbosity=1, resultclass=Result, stream=open(os.devnull, "w")).run(suite)
    node = subprocess.run(["node", "--test", os.path.join(ROOT, "tests", "frontend", "util.test.mjs")], capture_output=True, text=True)
    n = {k: int(v) for k, v in re.findall(r"^# (tests|pass|fail|skipped) (\d+)", node.stdout, re.M)}
    groups = {}
    names = {"test_01_app_and_security": "API, validation and security", "test_02_logic": "Rules, reports, comparison, persistence, export",
             "test_03_browser_integration": "Playwright integration (real Chromium)", "test_04_ui": "Frontend UI tests (Chromium)"}
    for tid, status, _ in res.rows:
        g = tid.split(".")[0]; d = groups.setdefault(g, {"name": names.get(g, g), "count": 0, "passed": 0}); d["count"] += 1; d["passed"] += status == "passed"
    wrapper = sum(1 for tid, *_ in res.rows if "test_node_unit_tests" in tid)      # counted once in unittest, expanded below
    py_cases = res.testsRun - wrapper
    layers = [{"name": groups[g]["name"] , "count": groups[g]["count"] - (wrapper if g == "test_04_ui" else 0)} for g in sorted(groups)]
    layers.append({"name": "Frontend unit tests (Node node:test)", "count": n.get("tests", 0)})
    failed = [r for r in res.rows if r[1] in ("failed", "error")] ; skipped = [r for r in res.rows if r[1] == "skipped"]
    total = py_cases + n.get("tests", 0)
    out = {"implemented": total, "executed": total - len(skipped), "passed": py_cases - len(failed) - len(skipped) + n.get("pass", 0), "failed": len(failed) + n.get("fail", 0),
           "not_executed": len(skipped), "duration_s": round(time.time() - t0), "unittest_reported": res.testsRun, "layers": layers,
           "environment": f"Python {platform.python_version()}, Node {subprocess.run(['node','--version'],capture_output=True,text=True).stdout.strip()}, {platform.system()} {platform.release()}, headless Chromium (Playwright)",
           "failures": [{"test": r[0], "detail": r[2]} for r in failed], "skipped": [r[0] for r in skipped],
           "tests": [{"id": r[0].split(".", 1)[1] if "." in r[0] else r[0], "status": r[1]} for r in res.rows]}
    json.dump(out, open(os.path.join(ROOT, "docs", "TESTING_REPORT.json"), "w"), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k not in ("tests", "layers")}, indent=1)); print("layers:", out["layers"])
    return 1 if out["failed"] else 0


if __name__ == "__main__":
    sys.exit(main())
