#!/usr/bin/env python3
"""Capture real screenshots of the running UI (uses ids from docs/demo-scenario-results.json)."""
import json, os, sys
from playwright.sync_api import sync_playwright
HERE = os.path.dirname(os.path.abspath(__file__)); BASE = os.environ.get("POCKETTEST_URL", "http://127.0.0.1:8000")
ids = json.load(open(os.path.join(HERE, "..", "docs", "demo-scenario-results.json")))["run_ids"]
OUT = os.path.join(HERE, "..", "docs", "screenshots")
shots = [("01-dashboard", "#/", None), ("02-new-test", f"#/new?profile=constrained&label=constrained", None),
         ("03-results", f"#/runs/{ids['constrained_before']}", None), ("04-report", f"#/runs/{ids['constrained_before']}/report", None),
         ("05-compare", f"#/compare?a={ids['constrained_before']}&b={ids['constrained_after']}", None), ("06-history", "#/history", None), ("07-settings", "#/settings", None)]
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1440, "height": 900})
    for name, route, _ in shots:
        pg.goto(BASE + "/" + route); pg.wait_for_timeout(1200); pg.screenshot(path=f"{OUT}/{name}.png"); print("saved", name)
    pg.goto(BASE + f"/#/runs/{ids['constrained_before']}/report"); pg.wait_for_timeout(800); pg.locator("details.f").first.scroll_into_view_if_needed()
    pg.set_viewport_size({"width": 1440, "height": 1500}); pg.screenshot(path=f"{OUT}/04b-report-detail.png", clip={"x": 240, "y": 0, "width": 1200, "height": 1500}); print("saved 04b")
    b.close()
