"""PocketTest AI HTTP API (Flask) + static frontend."""
import json
import urllib.request
import uuid

from flask import Flask, Response, jsonify, request, send_from_directory

from . import __version__, analysis, config, engine
from .compare import Incompatible, compare_runs
from .db import Repo
from .exports import CSV_PARTS, run_bundle, to_csv
from .runner import Busy, RunManager, ValidationError, validate_profile, validate_rules
from .workflows import list_workflows


def err(code, message, status):
    return jsonify({"error": {"code": code, "message": message}}), status


def create_app(repo=None, manager=None):
    app = Flask(__name__, static_folder=None)
    app.config["MAX_CONTENT_LENGTH"] = 256 * 1024
    repo = repo or Repo(config.DB_PATH)
    mgr = manager or RunManager(repo)
    app.repo, app.mgr = repo, mgr

    @app.errorhandler(ValidationError)
    def _v(e):
        return err("validation_error", str(e), 400)

    @app.errorhandler(Busy)
    def _b(e):
        return err("busy", str(e), 429)

    @app.errorhandler(404)
    def _404(e):
        return err("not_found", "Resource not found.", 404)

    @app.errorhandler(413)
    def _413(e):
        return err("too_large", "Request body too large.", 413)

    @app.errorhandler(Exception)
    def _500(e):
        app.logger.exception(e)
        return err("internal_error", "Internal server error.", 500)

    def body():
        b = request.get_json(silent=True)
        if not isinstance(b, dict):
            raise ValidationError("Request body must be a JSON object.")
        return b

    def full_run(rid):
        run = repo.get_run(rid)
        if not run:
            return None
        return {"run": run, **repo.run_data(rid)}

    @app.get("/api/health")
    def health():
        try:
            repo.list_runs(limit=1)
            db_ok = True
        except Exception:
            db_ok = False
        return jsonify({"status": "ok" if db_ok else "degraded", "version": __version__, "database": db_ok,
                        "active_runs": len(mgr.cancel_flags), "open_browsers": engine.open_browser_count(),
                        "llm_configured": analysis.llm_configured(), "max_concurrent_runs": config.MAX_CONCURRENT_RUNS})

    @app.get("/api/targets")
    def targets():
        out = []
        for t in mgr.targets():
            out.append({**t, "meta": mgr.target_meta(t)})
        return jsonify(out)

    @app.get("/api/workflows")
    def workflows():
        return jsonify(list_workflows())

    @app.get("/api/profiles")
    def profiles():
        return jsonify(mgr.profiles())

    @app.post("/api/profiles")
    def add_profile():
        p = validate_profile(body())
        p.update(id="custom-" + uuid.uuid4().hex[:6], builtin=False)
        repo.set_setting("custom_profiles", repo.get_setting("custom_profiles", []) + [p])
        return jsonify(p), 201

    @app.delete("/api/profiles/<pid>")
    def del_profile(pid):
        cur = repo.get_setting("custom_profiles", [])
        if not any(p["id"] == pid for p in cur):
            return err("not_found", "Custom profile not found (built-in profiles cannot be deleted).", 404)
        repo.set_setting("custom_profiles", [p for p in cur if p["id"] != pid])
        return jsonify({"deleted": pid})

    @app.get("/api/settings/rules")
    def get_rules():
        return jsonify({"rules": mgr.rules(), "defaults": config.default_rules()})

    @app.put("/api/settings/rules")
    def put_rules():
        new = validate_rules(body(), mgr.rules())
        repo.set_setting("rules", new)
        return jsonify({"rules": new})

    @app.post("/api/settings/rules/reset")
    def reset_rules():
        repo.set_setting("rules", {})
        return jsonify({"rules": config.default_rules()})

    @app.post("/api/runs")
    def start_run():
        rid = mgr.start(body())
        return jsonify({"id": rid}), 202

    @app.get("/api/runs")
    def list_runs():
        runs = repo.list_runs(status=request.args.get("status"), verdict=request.args.get("verdict"), date_from=request.args.get("from"),
                              date_to=request.args.get("to"), profile_id=request.args.get("profile_id"),
                              limit=min(int(request.args.get("limit", 200) or 200), 500))
        return jsonify(runs)

    @app.get("/api/runs/<rid>")
    def get_run(rid):
        r = full_run(rid)
        return jsonify(r) if r else err("not_found", "Run not found.", 404)

    @app.post("/api/runs/<rid>/cancel")
    def cancel(rid):
        return jsonify({"cancelled": mgr.cancel(rid)}) if repo.get_run(rid) else err("not_found", "Run not found.", 404)

    @app.delete("/api/runs/<rid>")
    def delete_run(rid):
        run = repo.get_run(rid)
        if not run:
            return err("not_found", "Run not found.", 404)
        if run["status"] in ("queued", "running"):
            return err("conflict", "Cancel the run before deleting it.", 409)
        repo.delete_run(rid)
        return jsonify({"deleted": rid})

    @app.get("/api/runs/<rid>/report")
    def get_report(rid):
        run = repo.get_run(rid)
        if not run:
            return err("not_found", "Run not found.", 404)
        rep = repo.get_report(rid)
        if not rep:
            return err("not_found", "No report yet (run not completed).", 404)
        return jsonify({"run": {k: run[k] for k in ("id", "label", "status", "verdict", "target_id", "profile", "workflow_id", "target_meta", "created_at")}, "report": rep})

    @app.post("/api/runs/<rid>/report/regenerate")
    def regen(rid):
        b = request.get_json(silent=True) or {}
        if not repo.get_run(rid):
            return err("not_found", "Run not found.", 404)
        return jsonify({"report": mgr.regenerate_report(rid, use_llm=bool(b.get("use_llm")))})

    @app.get("/api/runs/<rid>/export")
    def export(rid):
        r = full_run(rid)
        if not r:
            return err("not_found", "Run not found.", 404)
        fmt = request.args.get("format", "json")
        if fmt == "json":
            data = run_bundle(r["run"], {k: r[k] for k in ("steps", "requests", "page_metrics", "js_errors", "findings")}, repo.get_report(rid))
            return Response(json.dumps(data, indent=2), mimetype="application/json",
                            headers={"Content-Disposition": f"attachment; filename=pockettest-{rid}.json"})
        if fmt == "csv":
            part = request.args.get("part", "findings")
            if part not in CSV_PARTS:
                raise ValidationError(f"part must be one of {sorted(CSV_PARTS)}")
            return Response(to_csv(r, part), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=pockettest-{rid}-{part}.csv"})
        raise ValidationError("format must be json or csv")

    @app.get("/api/compare")
    def compare():
        a, b = request.args.get("a"), request.args.get("b")
        if not a or not b:
            raise ValidationError("Query parameters a (baseline) and b (new) are required.")
        if a == b:
            raise ValidationError("Choose two different runs.")
        ra, rb = repo.get_run(a), repo.get_run(b)
        if not ra or not rb:
            return err("not_found", "Run not found.", 404)
        try:
            return jsonify(compare_runs(ra, rb, repo.run_data(a)["findings"], repo.run_data(b)["findings"]))
        except Incompatible as e:
            return err("incompatible_runs", str(e), 409)

    @app.get("/api/stats")
    def stats():
        runs = repo.list_runs(limit=500)
        done = [r for r in runs if r["status"] == "completed"]
        issues = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for r in done:
            for k, v in (r["summary"] or {}).get("issue_counts", {}).items():
                issues[k] += v
        trend = [{"id": r["id"], "created_at": r["created_at"], "profile": r["profile"]["name"], "profile_id": r["profile_id"], "workflow_id": r["workflow_id"],
                  "median_load_ms": r["summary"]["median_load_ms"], "slowest_page_load_ms": r["summary"].get("slowest_page_load_ms", r["summary"]["median_load_ms"]), "median_api_ms": r["summary"]["median_api_ms"],
                  "verdict": r["verdict"], "label": r["label"], "optimized": (r["target_meta"] or {}).get("optimized")}
                 for r in reversed(done)]
        cats = {}
        for r in done:
            for k, v in r["summary"]["failure_categories"].items():
                cats[k] = cats.get(k, 0) + v
        return jsonify({"total_runs": len(runs), "completed": len(done), "failed_to_execute": sum(1 for r in runs if r["status"] == "failed"),
                        "passed": sum(1 for r in done if r["verdict"] == "passed"), "failed": sum(1 for r in done if r["verdict"] == "failed"),
                        "issues": issues, "total_issues": sum(issues.values()), "failure_categories": cats, "trend": trend,
                        "recent": [{k: r[k] for k in ("id", "label", "status", "verdict", "created_at", "profile_id", "workflow_id")} | {"profile": r["profile"]["name"], "issue_counts": (r["summary"] or {}).get("issue_counts")} for r in runs[:6]]})

    # ---- demo app control (only the registered demo target)
    def demo_url():
        return next(t["url"] for t in mgr.targets() if t["kind"] == "demo")

    @app.get("/api/demo/mode")
    def demo_get():
        return jsonify(mgr.target_meta(next(t for t in mgr.targets() if t["kind"] == "demo")))

    @app.post("/api/demo/mode")
    def demo_set():
        b = body()
        if not isinstance(b.get("optimized"), bool):
            raise ValidationError("optimized (boolean) is required.")
        if mgr.cancel_flags:
            raise Busy("Cannot change the demo app while a test is running.")
        req = urllib.request.Request(demo_url().rstrip("/") + "/_admin/mode", data=json.dumps({"optimized": b["optimized"]}).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=3) as r:
                return jsonify(json.loads(r.read()))
        except Exception as e:
            return err("demo_unreachable", f"Demo app not reachable: {type(e).__name__}", 502)

    # ---- frontend
    @app.get("/")
    def index():
        return send_from_directory(config.FRONTEND_DIR, "index.html")

    @app.get("/<path:p>")
    def static_files(p):
        if p.startswith("api/"):
            return err("not_found", "Resource not found.", 404)
        return send_from_directory(config.FRONTEND_DIR, p)

    return app
